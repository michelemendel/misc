using System;
using System.Collections.Generic;
using System.Text;

namespace Sky
{
	class Mobile
	{
		public Vector MoveVector = new Vector();
	}
}
