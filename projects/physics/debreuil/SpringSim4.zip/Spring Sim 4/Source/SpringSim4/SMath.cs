using System;
using Microsoft.DirectX;

namespace SpringSim4
{
    public static class SMath
    {
        #region Constraints
        public static Vector2 CalcCons_Length(Vector2 RP, Vector2 RV, float RestLength, out bool Snap)
		{
			float diff = RP.Length();

			if (diff > RestLength * Simulation.L_Snap_Length) Snap = true;
			else Snap = false;

			if (diff == 0) diff = 1;

			if (!Simulation.L_Expands) if (diff < RestLength) return Vector2.Empty;

			if (diff > Simulation.L_MaxDiff * RestLength) RP *= RestLength / diff;

			float finalForce = (
				(Simulation.L_Stiffness * (diff - RestLength)) +
				(Simulation.L_Damping * (RP.X * RV.X + RP.Y * RV.Y) / RestLength)) * 0.5F;

			RP.Multiply(finalForce * Simulation.L_UpdateAmount / diff);

			return RP;





			//float diff = RP.LengthSq();

			//if (diff > (RestLength * Simulation.L_Snap_Length) * (RestLength * Simulation.L_Snap_Length)) Snap = true;
			//else Snap = false;
			//if (!Simulation.L_Expands) if (diff < RestLength * RestLength) return Vector2.Empty;

			//float finalForce = (
			//    (Simulation.L_Stiffness * (diff - RestLength * RestLength)) +
			//    (Simulation.L_Damping * (RP.X * RV.X + RP.Y * RV.Y) / RestLength)) * 0.5F;

			//RP.Multiply(finalForce * Simulation.L_UpdateAmount / diff);

			//return RP;







           // Snap = false;
           // //delta = x2 - x1;

           // //Vector2 delta = RP;
           // //float deltalength = (float)Math.Sqrt(delta.X * delta.X + delta.Y * delta.Y);
           // //float diff = (deltalength - RestLength) / deltalength;
           // //return delta * 0.5F * diff;

           // float delta2 = RP.X * RP.X + RP.Y * RP.Y;

           // RP *= RestLength * RestLength / (delta2 + RestLength * RestLength) - 0.5F;

           // return -RP;

           //// delta *= restlength * restlength / (delta * delta + restlength * restlength) - 0.5;







            ////if (D_Position.LengthSq() >= (Target * S_Break) * (Target * S_Break)) return Vector2.Empty;
            //float diff = RP.Length();
            //if (diff > RestLength * Simulation.S_Break)
            //{
            //    Snap = true;
            //    return Vector2.Empty;
            //}
            //if (diff == 0) diff = 1;
            //if (diff > Simulation.S_MaxDiff * RestLength) RP.Multiply(RestLength * Simulation.S_MaxDiff / diff);
            //if (!Simulation.S_Expands) if (diff < RestLength)
            //    {
            //        Snap = false;
            //        return new Vector2(0, 0);
            //    }

            //float finalForce =
            //    (Simulation.S_Stiffness * (diff - RestLength)) +
            //    (Simulation.S_Damping * (RP.X * RV.X + RP.Y * RV.Y) / RestLength) * 0.5F;

            //RP.Normalize();
            //RP.Multiply(finalForce * Simulation.S_UpdateAmount / diff);

            ////Target *= Target;

            ////D_Position.X *= D_Position.X;
            ////D_Position.Y *= D_Position.Y;

            ////D_Position *= 1F / D_Position.LengthSq();

            ////D_Position *= ((S_Stiffness * (D_Position.LengthSq() - Target)) +
            ////        (S_Damping * 0.5F * (D_Position.X * D_Position.X + D_Position.Y * D_Position.Y) / Target)) * S_UpdateAmount;
            //Snap = false;
            //return RP;


            ////Vector2 RP = Location_1 - Location_2;
            ////float diff = RP.Length();
            ////if (diff == 0) diff = 1;
            ////if (!Expand) if (diff < RestLength) return new Vector2(0, 0);

            ////float finalForce = (
            ////    (Stiffness * (diff - RestLength)) +
            ////    (Damping * (RP.X * (Move_1.X - Move_2.X) + RP.Y * (Move_1.Y - Move_2.Y)) / RestLength)) * 0.5F;

            ////RP.Multiply(finalForce * Update / diff);

            ////return RP;
        }

		//public static bool CalcCons_Angle(Vector2 P1, Vector2 P2, Vector2 P3,
		//    Vector2 V_P1, Vector2 V_P2, Vector2 V_P3, int target, out Vector2 A_P1, out Vector2 A_P3)
		//{
		//    float P1toP2 = (float)Math.Atan2(P1.Y - P2.Y, P1.X - P2.X);
		//    float P3toP2 = (float)Math.Atan2(P3.Y - P2.Y, P3.X - P2.X);

		//    float diff = P1toP2 - P3toP2 + (float)target/(float)int.MaxValue*(float)Math.PI*2F;

		//    //diff %= (float)Math.PI * 2;
		//    //while (diff < 0) diff += (float)Math.PI * 2;

		//    if (Math.Abs(diff) > (float)Math.PI) diff = (float)(Math.PI - Math.Abs(diff))*Math.Sign(diff);

		//    A_P1 = new Vector2(-(P1.Y - P2.Y), (P1.X - P2.X)) * diff * Simulation.A_Stiffness;
		//       // (Simulation.A_Damping * ((P1.X - P2.X) * (V_P1.X - V_P2.X) + (P1.Y - P2.Y) * (V_P1.Y - V_P2.Y)) / diff) * 0.5F);

		//    A_P3 = new Vector2(-(P3.Y - P2.Y), (P3.X - P2.X)) * diff * Simulation.A_Stiffness;
		//       // (Simulation.A_Damping * ((P3.X - P2.X) * (V_P3.X - V_P2.X) + (P3.Y - P2.Y) * (V_P3.Y - V_P2.Y)) / diff) * 0.5F);

		//    return false;
		//}
        #endregion
    }
}
