using System;
using System.Drawing;
using Microsoft.DirectX;

namespace SpringSim4
{
    public struct Particle
    {
        public Particle(Vector2 Position, Vector2 Velocity)
        {
            this.Position = Position;
            this.Velocity = Velocity;
        }

        public Vector2 Position;
        public Vector2 Velocity;
    }
}
