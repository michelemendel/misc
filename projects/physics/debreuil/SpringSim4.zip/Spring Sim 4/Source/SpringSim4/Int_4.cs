using System;

namespace SpringSim4
{
    public struct Int_4
    {
        public Int_4(int N1, int N2, int N3, int N4)
        {
            this.N1 = N1;
            this.N2 = N2;
            this.N3 = N3;
            this.N4 = N4;
        }

        public int N1;
        public int N2;
        public int N3;
        public int N4;
    }
}
