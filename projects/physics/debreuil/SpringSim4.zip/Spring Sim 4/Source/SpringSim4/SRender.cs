using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace SpringSim4
{
    public class SRender
    {
        public SRender(Form parent, bool fullscreen)
        {
            this.windowed = !fullscreen;
            this.parent = parent;
            ResetDevice();
        }

        public static readonly int Width = Manager.Adapters[0].CurrentDisplayMode.Width;
        public static readonly int Height = Manager.Adapters[0].CurrentDisplayMode.Height;

        public Device render;
        private Form parent;

        private Sprite RenderSprite;
        private Texture OverlayTexture;

        private readonly bool windowed;

        private void ResetDevice()
        {
            PresentParameters presentParams = new PresentParameters();
            presentParams.SwapEffect = SwapEffect.Discard;

            Format current = Manager.Adapters[0].CurrentDisplayMode.Format;

            if (Manager.CheckDeviceType(0, DeviceType.Hardware, current, current, false))
            {
                presentParams.Windowed = windowed;
                presentParams.SwapEffect = SwapEffect.Copy;
                presentParams.BackBufferFormat = current;
                presentParams.BackBufferCount = 0;
                presentParams.BackBufferWidth = Width;
				presentParams.BackBufferHeight = Height;
				//presentParams.MultiSample = MultiSampleType.NonMaskable;
				//presentParams.MultiSampleQuality = 2;
            }
            else presentParams.Windowed = true;

            render = new Device(0, DeviceType.Hardware, parent, CreateFlags.HardwareVertexProcessing, presentParams);
            render.VertexFormat = CustomVertex.TransformedColored.Format;
            render.RenderState.AlphaBlendEnable = true;

            render.RenderState.CullMode = Cull.None;

            render.DeviceLost += new EventHandler(render_Lost);

            RenderSprite = new Sprite(render);
            OverlayTexture = new Texture(render, SRender.Width, SRender.Height, 1, Usage.None, current, Pool.Managed);
        }

        private void render_Lost(object sender, EventArgs e)
        {
            parent.Close();
            //ResetDevice();
        }

		public int[] LoadTextureColors(string name, out float width, out float height)
		{
			Texture textureOrig = LoadTexture(name);

			// textureOrig is the original greyscale image. 
			SurfaceDescription desc;
			desc = textureOrig.GetLevelDescription(0);
			width = desc.Width;
			height = desc.Height;
			Texture textureCopy = new Texture(render, desc.Width, desc.Height, 1, 0, desc.Format, Pool.Managed);
			Surface dst = textureCopy.GetSurfaceLevel(0);
			Surface src = textureOrig.GetSurfaceLevel(0);
			SurfaceLoader.FromSurface(dst, src, Filter.None, 0);
			desc = textureOrig.GetLevelDescription(0);
 
			// Get the bits for the surface and re-color them
			return (int[])dst.LockRectangle(typeof(int), LockFlags.None, desc.Width * desc.Height);
			
		}

		public Texture LoadTexture(string name)
		{
			return TextureLoader.FromFile(render, name);
		}

        public void Clear(int color)
        {
            render.Clear(ClearFlags.Target, color, 1.0F, 0);
        }

        public void DrawOverlay(int alpha)
		{
			render.RenderState.SourceBlend = Blend.BothSourceAlpha;
			render.RenderState.DestinationBlend = Blend.BothInvSourceAlpha;

            RenderSprite.Begin(SpriteFlags.SortTexture);
            RenderSprite.Draw2D(OverlayTexture, Point.Empty, 0, Point.Empty, Color.FromArgb(alpha, 0, 0, 0));
            RenderSprite.End();
        }

        public void BeginScene()
        {
            render.BeginScene();
        }

        public void EndScene()
        {
            render.EndScene();
            render.Present();
        }

        public void DrawLines(Vector4[] points, int color)
		{
			render.RenderState.SourceBlend = Blend.SourceAlpha;
			render.RenderState.DestinationBlend = Blend.DestinationAlpha;

            CustomVertex.TransformedColored[] vData = new CustomVertex.TransformedColored[points.Length];
            for (int i = 0; i < vData.Length; i++)
            {
                vData[i].Color = color;
                vData[i].Position = points[i];
            }
            render.DrawUserPrimitives(PrimitiveType.LineList, vData.Length / 2, vData);
        }

        public void DrawPoints(Vector4[] points, int color)
        {
			render.RenderState.SourceBlend = Blend.SourceAlpha;
			render.RenderState.DestinationBlend = Blend.DestinationAlpha;

            CustomVertex.TransformedColored[] vData = new CustomVertex.TransformedColored[points.Length];
            for (int i = 0; i < vData.Length; i++)
            {
                vData[i].Color = color;
                vData[i].Position = points[i];
            }
            render.DrawUserPrimitives(PrimitiveType.PointList, vData.Length, vData);
        }

        public void DrawBlurLine(Vector4[] points, Color startColor, Color endColor, float alphaLength)
        {
			render.RenderState.SourceBlend = Blend.SourceAlpha;
			render.RenderState.DestinationBlend = Blend.DestinationAlpha;

			CustomVertex.TransformedColored[] qData = new CustomVertex.TransformedColored[points.Length * 6];
			CustomVertex.TransformedColored[] lData = new CustomVertex.TransformedColored[points.Length * 2];

			for (int i = 0; i < points.Length; i += 4)
			{
				float l_03 = alphaLength / (points[i + 0] - points[i + 3]).Length();
				float l_12 = alphaLength / (points[i + 1] - points[i + 2]).Length();

				int aC_0 = (int)(endColor.A * l_03);
				int aC_1 = (int)(endColor.A * l_03);
				int aC_2 = (int)(startColor.A * l_12);
				int aC_3 = (int)(startColor.A * l_12);

				if (aC_0 > 255) aC_0 = 255;
				if (aC_1 > 255) aC_1 = 255;
				if (aC_2 > 255) aC_2 = 255;
				if (aC_3 > 255) aC_3 = 255;

				qData[(int)(i * 0.25 * 6) + 0].Color = Color.FromArgb(aC_0, endColor).ToArgb();
				qData[(int)(i * 0.25 * 6) + 1].Color = Color.FromArgb(aC_1, endColor).ToArgb();
				qData[(int)(i * 0.25 * 6) + 2].Color = Color.FromArgb(aC_3, startColor).ToArgb();
				qData[(int)(i * 0.25 * 6) + 3].Color = Color.FromArgb(aC_0, endColor).ToArgb();
				qData[(int)(i * 0.25 * 6) + 4].Color = Color.FromArgb(aC_3, startColor).ToArgb();
				qData[(int)(i * 0.25 * 6) + 5].Color = Color.FromArgb(aC_2, startColor).ToArgb();

				qData[(int)(i * 0.25 * 6) + 0].Position = points[i + 0];
				qData[(int)(i * 0.25 * 6) + 1].Position = points[i + 1];
				qData[(int)(i * 0.25 * 6) + 2].Position = points[i + 3];
				qData[(int)(i * 0.25 * 6) + 3].Position = points[i + 0];
				qData[(int)(i * 0.25 * 6) + 4].Position = points[i + 3];
				qData[(int)(i * 0.25 * 6) + 5].Position = points[i + 2];

				//qData[0].Color = Color.FromArgb(aC_0, endColor).ToArgb();
				//qData[1].Color = Color.FromArgb(aC_1, endColor).ToArgb();
				//qData[2].Color = Color.FromArgb(aC_2, startColor).ToArgb();
				//qData[3].Color = Color.FromArgb(aC_3, startColor).ToArgb();
					  
				//qData[0].Position = points[i + 0];
				//qData[1].Position = points[i + 1];
				//qData[2].Position = points[i + 3];
				//qData[3].Position = points[i + 2];

				//Line
				float mul_c2 = (float)aC_2 / 255F;
				float mul_c3 = (float)aC_3 / 255F;

				int aC_2_L = (int)(aC_2 * Simulation.C_Constraint_LineAMultiply);
				int aC_3_L = (int)(aC_3 * Simulation.C_Constraint_LineAMultiply);
				if(aC_2_L > 255) aC_2_L = 255;
				if(aC_3_L > 255) aC_3_L = 255;

				lData[(int)(i * 0.5F)].Position = qData[(int)(i * 0.25 * 6) + 2].Position;
				lData[(int)(i * 0.5F) + 1].Position = qData[(int)(i * 0.25 * 6) + 5].Position;

				lData[(int)(i * 0.5F)].Color = Color.FromArgb(aC_2_L, startColor).ToArgb();
				lData[(int)(i * 0.5F) + 1].Color = Color.FromArgb(aC_3_L, startColor).ToArgb();
			}

			render.DrawUserPrimitives(PrimitiveType.TriangleList, points.Length*2, qData);
			render.DrawUserPrimitives(PrimitiveType.LineList, (int)(lData.Length * 0.5F), lData);
        }
    }
}
