using System;
using System.Drawing;
using Microsoft.DirectX;

namespace SpringSim4
{
    public static class Simulation
    {
		//Rendering
		public static bool Fullscreen = true;

		public static ConstraintStyle Style_Constraint = ConstraintStyle.Length;
		public static DrawStyle Style_Draw = DrawStyle.Line;

        //Length
        public static float L_Snap_Length = 10.8F;
        public static float L_MaxDiff = 1.6F;
        public static float L_Stiffness = 0.8F;
        public static float L_Damping = 0.4F;
        public static float L_UpdateAmount = 1.2F;
        public static bool L_Expands = true;

		//Color
		public static float C_Constraint_LineAMultiply = 0.3F;
		public static float C_Constraint_AlphaLength = 2;
		public static Color C_Constraint_Start = Color.Empty;
        public static Color C_Constraint_End = Color.FromArgb(255, 255, 255);
        public static int C_Clear = Color.FromArgb(0, 0, 0).ToArgb();
        public static int C_OverlayAlpha = 100;

		//Simulation
        public static float Slices = 20;
        public static float Gravity = 0.2F;
        public static float Edge_EnergyLoss = 0.6F;

		//Mouse
        public static bool Mouse_Left;
		public static bool Mouse_Right;
		public static Vector2 Mouse_Position;
		public static Vector2 Mouse_PositionLast;

		//Program State
        public static bool Paused = false;

		//Line
		public static int SimProp_LineSegments = 1;
		public static float SimProp_LineWidth = SRender.Width * 0.2F;

		//From Image Generation
		public static float GenImg_Restlengh = 15;

		//Box
		public static float SimProp_BoxWidth = 400;
		public static float SimProp_BoxHeight = 800;
		public static float SimProp_BoxRestLength = 20;
		public static Vector2 SimProp_BoxTopMiddle = new Vector2(SRender.Width * 0.5F, SRender.Height * 0.1F);

		//Triangle
		public static float SimProp_TriangleWidth = 1000;//800;
		public static float SimProp_TriangleHeight = 1000;//1000;
		public static float SimProp_TriangleSegLength = 20;
		public static Vector2 SimProp_TriangleTopMiddle = new Vector2(SRender.Width * 0.5F, (SRender.Height - 1000)*2);

		//Affect
		public static float Affect_Radius = 60;
		public static float Affect_Stiffness = 0.15F;

		//Shape
		public static string Shape_TextureName = "shape.png";

        #region Load States

		public static void S_Line(float width, int segments, float rBreak, Vector2 center,
			out Int_3[] out_cons_Length, out Particle[] out_particles)
		{
			Int_3[] cons_Length = new Int_3[segments];
			Int_4[] cons_Angle = new Int_4[segments - 1];
			Particle[] particles = new Particle[segments + 1];

			center.X -= width * 0.5F;

			float segmentLength = width / (float)segments;
			//int segmentLength2 = (int)(segmentLength * segmentLength);
			for (int i = 0; i < particles.Length; i++)
			{
				particles[i] = new Particle(
					new Vector2(center.X + segmentLength * i, center.Y),
					new Vector2(0, 0));

				if (i < cons_Length.Length) cons_Length[i] = new Int_3(i, i + 1, (int)segmentLength);
				if (i < cons_Length.Length && i > 0)
					cons_Angle[i - 1] = new Int_4(i - 1, i, i + 1, (int)((float)int.MaxValue / 2F));
			}

			out_cons_Length = cons_Length;
			//out_cons_Angle = cons_Angle;
			out_particles = particles;
		}

		public static void S_Box(float uW, float uH, float restLength, Vector2 topMiddle,
			out Int_3[] out_cons_Length, out Particle[] out_particles)
		{
			int width = (int)(uW / restLength) + 1;
			int height = (int)(uH / restLength) + 1;

		    float X_inset = topMiddle.X - (width * restLength) / 2;
		    float Y_inset = topMiddle.Y;

			Particle[] particles = new Particle[width * height];

		    for (int w = 0; w < width; w++)
		    {
		        for (int h = 0; h < height; h++)
		        {
					particles[w * height + h] = new Particle(new Vector2
		                (
		                    X_inset + w * restLength,
		                    Y_inset + h * restLength
		                ), new Vector2(0, 0));
		        }
			}

			//Constraints

			Int_3[] cons_Length = new Int_3[width * (height - 1) +
											(width - 1) * height +
											(width - 1) * (height - 1) * 2];

			int cAdded = 0;
			for (int w = 0; w < width; w++)
			{
				for (int h = 0; h < height - 1; h++)
				{
					cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + 1, restLength);
					cAdded++;
				}
			}

			for (int w = 0; w < width - 1; w++)
			{
				for (int h = 0; h < height; h++)
				{
					cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + height, restLength);
					cAdded++;
				}
			}

			float dRestLength = new Vector2(restLength, restLength).Length();

			for (int w = 0; w < width - 1; w++)
			{
				for (int h = 0; h < height - 1; h++)
				{
					cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + height + 1, dRestLength);
					cAdded++;
					cons_Length[cAdded] = new Int_3(w * height + h + 1, w * height + h + height, dRestLength);
					cAdded++;
				}
			}

			out_cons_Length = cons_Length;
			out_particles = particles;
		}

		public static void S_Triangle(float width, float height, float seg_Length, Vector2 topMiddle,
			out Int_3[] out_cons_Length, out Particle[] out_particles)
		{
			width *= 0.5F;
			height *= 0.5F;

			float hw_Ratio = height / width;
			//{
			//    hw_Ratio = width / height;
			//}

			float tSide_Length = new Vector2(width, height * 0.5F).Length() * 2;

			//seg_Length = seg_Length;
			float seg_num = (int)(tSide_Length / seg_Length);
			seg_Length = tSide_Length / seg_num;
			//tSide_Length = seg_num * seg_Length;

			if (hw_Ratio > 1) seg_Length /= hw_Ratio;
			//else hw_Ratio = 1 / hw_Ratio;
			
			//seg_Length *= hw_Ratio;
			//float width = new Vector2(tSide_Length, tSide_Length).Length();

			float iX = topMiddle.X;
			float iY = topMiddle.Y;

			int particle_Index = 0;
			int constraint_Index = 0;

			int l_par = 0;
			for (int i = 0; i < seg_num; i++) l_par += i + 1;

			int l_con = 0;
			for (int i = 0; i < seg_num; i++) l_con += i * 2; 
			for (int i = 0; i < seg_num; i++) l_con += i;

			Particle[] particles = new Particle[l_par];
			Int_3[] constraints = new Int_3[l_con];

			//float seg_DiagWidth = new Vector2(seg_Length, seg_Length*0.5F);
			float segHeight = (float)Math.Sqrt((seg_Length * seg_Length) + ((seg_Length * 0.5F) * (seg_Length * 0.5F)));
			for (int cur_Level = 0; cur_Level < seg_num; cur_Level++)
			{
				for (int cur_Across = 0; cur_Across < cur_Level + 1; cur_Across++)
				{
					//float cRatioX = 1;
					//float cRatioY = hw_Ratio;
					//if (hw_Ratio < 1)
					//{
					//    cRatioX = hw_Ratio;
					//    cRatioY = 1;
					//}

					particles[particle_Index] = new Particle
						(
							new Vector2
							(
								iX + (cur_Across * seg_Length - cur_Level * (seg_Length * 0.5F)),
								iY + cur_Level * (seg_Length * (seg_Length / segHeight)) * hw_Ratio
							),
							new Vector2(0, 0)
						);
					particle_Index++;
				}
			}

			float diagSegLength = (particles[0].Position - particles[2].Position).Length();//new Vector2(seg_Length*hw_Ratio, seg_Length).Length();
			//float cSegLength = (particles[1].Position - particles[2].Position).Length();

			int startLevel_Index = 0;
			int levelLength = 0;
			int lastIndex = 0;
			for (int cur_Level = 0; cur_Level < seg_num-1; cur_Level++)
			{
				startLevel_Index += cur_Level;
				levelLength = cur_Level+1;
				for (int cur_Across = 0; cur_Across < cur_Level+1; cur_Across++)
				{
					int curIndex = startLevel_Index + cur_Across;

					//Left
					constraints[constraint_Index] = new Int_3(
						curIndex,
						curIndex + levelLength,
						diagSegLength);
					constraint_Index++;

					//Right
					constraints[constraint_Index] = new Int_3(
						curIndex,
						curIndex + levelLength + 1,
						diagSegLength);
					constraint_Index++;

					if (levelLength - cur_Across > 1)
					{
						constraints[constraint_Index] = new Int_3(
							curIndex,
							curIndex + 1,
							seg_Length);
						constraint_Index++;
						lastIndex = curIndex;
					}
				}
			}

			lastIndex++;
			for (int i = 0; i < levelLength; i++)
			{
				lastIndex++;
				constraints[constraint_Index] = new Int_3(
					lastIndex,
					lastIndex + 1,
					seg_Length);
				constraint_Index++;
			}

			//Particle[] particles = new Particle[width * height];

			//for (int w = 0; w < width; w++)
			//{
			//    for (int h = 0; h < height; h++)
			//    {
			//        particles[w * height + h] = new Particle(new Vector2
			//            (
			//                X_inset + w * restLength,
			//                Y_inset + h * restLength
			//            ), new Vector2(0, 0));
			//    }
			//}

			////Constraints

			//Int_3[] cons_Length = new Int_3[width * (height - 1) +
			//                                (width - 1) * height +
			//                                (width - 1) * (height - 1) * 2];

			//int cAdded = 0;
			//for (int w = 0; w < width; w++)
			//{
			//    for (int h = 0; h < height - 1; h++)
			//    {
			//        cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + 1, (int)restLength);
			//        cAdded++;
			//    }
			//}

			//for (int w = 0; w < width - 1; w++)
			//{
			//    for (int h = 0; h < height; h++)
			//    {
			//        cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + height, (int)restLength);
			//        cAdded++;
			//    }
			//}

			//int dRestLength = (int)new Vector2(restLength, restLength).Length();

			//for (int w = 0; w < width - 1; w++)
			//{
			//    for (int h = 0; h < height - 1; h++)
			//    {
			//        cons_Length[cAdded] = new Int_3(w * height + h, w * height + h + height + 1, dRestLength);
			//        cAdded++;
			//        cons_Length[cAdded] = new Int_3(w * height + h + 1, w * height + h + height, dRestLength);
			//        cAdded++;
			//    }
			//}

			out_cons_Length = constraints;
			out_particles = particles;
		}

		//public static void Box(Vector2 topMiddle, float uBoxW, float uBoxH, float restLength, bool TFixed, ref Atom[] atoms, ref Constraint[] constraints)
		//{
		//    int width = (int)(uBoxW / restLength) + 1;
		//    int height = (int)(uBoxH / restLength) + 1;

		//    float X_inset = topMiddle.X - (width * restLength) / 2;
		//    float Y_inset = topMiddle.Y;

		//    //Set Atoms
		//    atoms = new Atom[width * height];

		//    for (int w = 0; w < width; w++)
		//    {
		//        for (int h = 0; h < height; h++)
		//        {
		//            atoms[w * height + h] = new Atom(new Vector2
		//                (
		//                    X_inset + w * restLength,
		//                    Y_inset + h * restLength
		//                ), new Vector2(0, 0), false);
		//        }
		//    }
		//    if (TFixed) for (int i = 0; i < width; i++) atoms[i * height].Fixed = true;

		//    //Set Constraints
		//    constraints = new Constraint[width * (height - 1) +
		//                                    (width - 1) * height +
		//                                    (width - 1) * (height - 1) * 2];

		//    int cAdded = 0;
		//    for (int w = 0; w < width; w++)
		//    {
		//        for (int h = 0; h < height - 1; h++)
		//        {
		//            constraints[cAdded] = new Constraint(w * height + h, w * height + h + 1, restLength);
		//            cAdded++;
		//        }
		//    }

		//    for (int w = 0; w < width - 1; w++)
		//    {
		//        for (int h = 0; h < height; h++)
		//        {
		//            constraints[cAdded] = new Constraint(w * height + h, w * height + h + height, restLength);
		//            cAdded++;
		//        }
		//    }

		//    float dRestLength = new Vector2(restLength, restLength).Length();

		//    for (int w = 0; w < width - 1; w++)
		//    {
		//        for (int h = 0; h < height - 1; h++)
		//        {
		//            constraints[cAdded] = new Constraint(w * height + h, w * height + h + height + 1, dRestLength);
		//            cAdded++;
		//            constraints[cAdded] = new Constraint(w * height + h + 1, w * height + h + height, dRestLength);
		//            cAdded++;
		//        }
		//    }
		//}

        #endregion
    }
}
