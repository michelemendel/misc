using System;
using System.Windows.Forms;
using Drawing = System.Drawing;
using DirectX = Microsoft.DirectX;
using Direct3D = Microsoft.DirectX.Direct3D;

namespace SpringSim4
{
    public class Base : Form
    {
        public Base()
        {
            SetVariables();
            CreateForm();
            CreateTimer();
			Restart(lastRestartI);
        }

        private SRender render;
        private Timer timer;

        private Particle[] particles;
        private Int_3[] cons_Length;
       // private Int_4[] cons_Angle;

        private int activeConstraints;
        private int selectedParticle;

		private int lastRestartI = 1;

        # region Initilization
        private void SetVariables()
        {
			Simulation.C_Constraint_Start = Simulation.C_Constraint_End;
			Simulation.C_Constraint_End = 
				Drawing.Color.FromArgb(
				(int)((float)Simulation.C_Constraint_End.A*((255F-(float)Simulation.C_OverlayAlpha)/255F)),
				Simulation.C_Constraint_End);
        }

        private void CreateForm()
        {
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Drawing.Point(0, 0);

            this.Cursor = Cursors.Cross;
            this.Size = new Drawing.Size(SRender.Width, SRender.Height);
            this.FormBorderStyle = FormBorderStyle.None;
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.Opaque, true);

            this.Show();
            render = new SRender(this, Simulation.Fullscreen);
        }

        private void CreateTimer()
        {
            timer = new Timer();
            timer.Interval = (int)(1000F / 60F);
            timer.Tick += new EventHandler(Tick);
            timer.Enabled = true;
        }
        #endregion

        private void Restart(int restartIndex)
		{
			lastRestartI = restartIndex;

			switch (restartIndex)
			{
				//Box
				case 1:

					Simulation.S_Box(
						SRender.Width, SRender.Height,
						Simulation.GenImg_Restlengh,
						new DirectX.Vector2(SRender.Width * 0.5F, 0), out cons_Length, out particles);
					Simulation.L_Snap_Length = 1.4F;
					break;

				//Triangle
				case 2:

					float size = Simulation.SimProp_TriangleWidth * 4;
					Simulation.S_Triangle(
						size, size, Simulation.GenImg_Restlengh, 
						new DirectX.Vector2(SRender.Width * 0.5F, -size/2),
						out cons_Length, out particles);
					Simulation.L_Snap_Length = 1.6F;
					break;
			}
			//Simulation.S_Line(Simulation.SimProp_LineWidth, Simulation.SimProp_LineSegments,
			//    Simulation.L_Snap_Length, new DirectX.Vector2(Width * 0.5F, Height * 0.5F),
			//    out cons_Length, out particles);
			//Simulation.L_Snap_Length = 1000F;

			//Simulation.S_Box(
			//    Simulation.SimProp_BoxWidth, Simulation.SimProp_BoxHeight,
			//    Simulation.SimProp_BoxRestLength,
			//    Simulation.SimProp_BoxTopMiddle, out cons_Length, out particles);
			//Simulation.L_Snap_Length = 1.4F;


			//Simulation.S_Triangle(
			//    Simulation.SimProp_TriangleWidth, Simulation.SimProp_TriangleHeight,
			//    Simulation.SimProp_TriangleSegLength, Simulation.SimProp_TriangleTopMiddle,
			//    out cons_Length, out particles);
			//Simulation.L_Snap_Length = 1.6F;


			//DirectX.Vector2 testPoint = new Microsoft.DirectX.Vector2(640, 600);
			//float shapeRadius = 100;
			//shapeRadius *= shapeRadius;

			//for (int i = 0; i < cons_Length.Length; i++)
			//{
			//    if ((testPoint - particles[cons_Length[i].N1].Position).LengthSq() > shapeRadius)
			//    {
			//        cons_Length[i].N3 = -Math.Abs(cons_Length[i].N3);
			//        activeConstraints--;
			//    }
			//    else if ((testPoint - particles[cons_Length[i].N2].Position).LengthSq() > shapeRadius)
			//    {
			//        cons_Length[i].N3 = -Math.Abs(cons_Length[i].N3);
			//        activeConstraints--;
			//    }
			//}

			activeConstraints = cons_Length.Length;

			CutFromImage();
			CleanConstraintArrays();
			RemoveIsolatedConstrints();

			Simulation.Mouse_Position = new DirectX.Vector2(Cursor.Position.X, Cursor.Position.Y);
			Simulation.Mouse_PositionLast = Simulation.Mouse_Position;
			render.Clear(Simulation.C_Clear);
        }

		private void CutFromImage()
		{
			int checkColor = Drawing.Color.FromArgb(255, 255, 255).ToArgb();
			float texWidth;
			float texHeight;
			int[] shapeArray = render.LoadTextureColors(Simulation.Shape_TextureName, out texWidth, out texHeight);

			for (int i = 0; i < cons_Length.Length; i++)
			{
				bool hasDeleted = false;
				int consSide = cons_Length[i].N1;
				for (int cP = 0; cP < 2; cP++)
				{
					if (cP == 1) consSide = cons_Length[i].N2;

					float xRatio = (particles[consSide].Position.X / SRender.Width);
					float yRatio = (particles[consSide].Position.Y / SRender.Height);

					if (xRatio > 1) xRatio = 1;
					if (yRatio > 1) yRatio = 1;

					if (xRatio < 0) xRatio = 0;
					if (yRatio < 0) yRatio = 0;

					int cIndex = (int)(
							xRatio * texWidth +
							texWidth * (int)(texHeight * yRatio)

						 );
					if (cIndex > shapeArray.Length - 1) continue;
					if (shapeArray[cIndex] != checkColor)
					{
						cons_Length[i].N3 = -Math.Abs(cons_Length[i].N3);

						if (!hasDeleted)
						{
							activeConstraints--;
							hasDeleted = true;
						}
					}
				}
			}
			for (int i = 0; i < cons_Length.Length; i++)
			{
				if(cons_Length[i].N3 < 0) continue;

				if (particles[cons_Length[i].N1].Position.X < 0)
				{
					cons_Length[i].N3 *= -1;
					activeConstraints--;
				}
				else if (particles[cons_Length[i].N1].Position.X > SRender.Width)
				{
					cons_Length[i].N3 *= -1;
					activeConstraints--;
				}

				else if (particles[cons_Length[i].N1].Position.Y < 0)
				{
					cons_Length[i].N3 *= -1;
					activeConstraints--;
				}
				else if (particles[cons_Length[i].N1].Position.Y > SRender.Height)
				{
					cons_Length[i].N3 *= -1;
					activeConstraints--;
				}
			}
		}

		private void RemoveIsolatedConstrints()
		{

		}

		private void CleanConstraintArrays()
		{
			Int_3[] t_cons = new Int_3[activeConstraints];
			int t_cons_Index = 0;

			for (int i = 0; i < cons_Length.Length; i++)
			{
				if (cons_Length[i].N3 < 0) continue;
				t_cons[t_cons_Index] = cons_Length[i];
				t_cons_Index++;
			}

			cons_Length = t_cons;

			//Remove unused particles
			bool[] particlesW_Cons = new bool[particles.Length];

			int usedParticles = 0;
			for (int i = 0; i < cons_Length.Length; i++)
			{
				if (!particlesW_Cons[cons_Length[i].N1])
				{
					particlesW_Cons[cons_Length[i].N1] = true;
					usedParticles++;
				}
				if (!particlesW_Cons[cons_Length[i].N2])
				{
					particlesW_Cons[cons_Length[i].N2] = true;
					usedParticles++;
				}
			}

			int[] newConsIndexes = new int[particles.Length];
			Particle[] tempParticles = new Particle[usedParticles];

			int uP_Index = 0;
			for (int i = 0; i < particles.Length; i++)
			{
				if (particlesW_Cons[i])
				{
					newConsIndexes[i] = uP_Index;
					tempParticles[uP_Index] = particles[i];
					uP_Index++;
				}
			}
			
			particles = tempParticles;

			for (int i = 0; i < cons_Length.Length; i++)
			{
				cons_Length[i].N1 = newConsIndexes[cons_Length[i].N1];
				cons_Length[i].N2 = newConsIndexes[cons_Length[i].N2];
			}
		}

        private void UpdateWorld()
        {
			Simulation.Mouse_PositionLast = Simulation.Mouse_Position;
			Simulation.Mouse_Position = new DirectX.Vector2(Cursor.Position.X, Cursor.Position.Y);

			if (Simulation.C_OverlayAlpha != 255) render.DrawOverlay(Simulation.C_OverlayAlpha);
			else render.Clear(Drawing.Color.FromArgb(0, 0, 0).ToArgb());

            render.BeginScene(); 

			DirectX.Vector4[] consDraw_polygon = new DirectX.Vector4[activeConstraints * 4];
			//DirectX.Vector4[] consDraw_lines = new DirectX.Vector4[activeConstraints * 2];
			if (consDraw_polygon.Length == 0)
			{
				render.EndScene();
				return;
			}
			int iP = 0;
			int iL = 0;

            DirectX.Vector2 constraintForce_1;
            //DirectX.Vector2 constraintForce_3;
            float updateLength = 1F / (float)Simulation.Slices;

			bool[] C_WasSnapped = new bool[cons_Length.Length];
            //Draw
            for (int i = 0; i < cons_Length.Length; i++)
            {
				if (cons_Length[i].N3 < 0)
				{
					C_WasSnapped[i] = true;
					continue;
				}
				else C_WasSnapped[i] = false;

                consDraw_polygon[iP] = new DirectX.Vector4(
                    particles[cons_Length[i].N1].Position.X,
                    particles[cons_Length[i].N1].Position.Y, 0, 0);

                consDraw_polygon[iP + 1] = new DirectX.Vector4(
                    particles[cons_Length[i].N2].Position.X,
                    particles[cons_Length[i].N2].Position.Y, 0, 0);
                iP += 4;
            }

            for (float cSlice = 0; cSlice < Simulation.Slices; cSlice++)
			{
				Interact(cSlice / (float)Simulation.Slices, true);

                //Particles
                for (int i = 0; i < particles.Length; i++)
                {
                    particles[i].Velocity.Y += Simulation.Gravity * updateLength;
                    particles[i].Position += particles[i].Velocity * updateLength;

                    if (particles[i].Position.Y > SRender.Height)
					{
						particles[i].Velocity.Y *= -Simulation.Edge_EnergyLoss;
						particles[i].Velocity.X *= Simulation.Edge_EnergyLoss;
                        particles[i].Position.Y = SRender.Height;
                    }
                    else if (particles[i].Position.Y < 0)
                    {
						particles[i].Velocity.Y *= -Simulation.Edge_EnergyLoss;
						particles[i].Velocity.X *= Simulation.Edge_EnergyLoss;
                        particles[i].Position.Y *= -1;
                    }

                    if (particles[i].Position.X > SRender.Width)
                    {
						particles[i].Velocity.X *= -Simulation.Edge_EnergyLoss;
						particles[i].Velocity.Y *= Simulation.Edge_EnergyLoss;
                        particles[i].Position.X = SRender.Width;
                    }
                    else if (particles[i].Position.X < 0)
                    {
						particles[i].Velocity.X *= -Simulation.Edge_EnergyLoss;
						particles[i].Velocity.Y *= Simulation.Edge_EnergyLoss;
                        particles[i].Position.X *= -1;
                    }
                        
                }

                //Length Constraints
                for (int i = 0; i < cons_Length.Length; i++)
                {
                    if (cons_Length[i].N3 < 0) continue;




					////Vector2 k1Vel =											vel;
					////Vector2 k1Acc =											f(t, pos, vel);

					////Vector2 k2Vel =											vel + 0.5f * dt * k1Acc;
					////Vector2 k2Acc =											f(t + 0.5f * dt, pos + 0.5f * dt * k1Vel, k2Vel);

					////Vector2 k3Vel =											vel + 0.5f * dt * k2Acc;
					////Vector2 k3Acc =											f(t + 0.5f * dt, pos + 0.5f * dt * k2Vel, k3Vel);

					////Vector2 k4Vel =											vel + dt * k3Acc;
					////Vector2 k4Acc =											f(t + dt, pos + dt * k3Vel, k4Vel);

					////pos += (dt / 6.0f) * (k1Vel + 2.0f * k2Vel + 2.0f * k3Vel + k4Vel);
					////vel += (dt / 6.0f) * (k1Acc + 2.0f * k2Acc + 2.0f * k3Acc + k4Acc);
					//bool snapped;

					//float t = 1;//cSlice * (1F / Simulation.Slices);
					//float dt = 1F/(float)Simulation.Slices;
					//DirectX.Vector2 vel = (particles[cons_Length[i].N1].Velocity - particles[cons_Length[i].N2].Velocity);
					//DirectX.Vector2 pos = (particles[cons_Length[i].N1].Position - particles[cons_Length[i].N2].Position);

					//DirectX.Vector2 k1Vel =										vel;
					//DirectX.Vector2 k1Acc = SMath.CalcCons_Length(				t, pos, vel,
					//    cons_Length[i].N3, out snapped);

					//DirectX.Vector2 k2Vel =										vel + 0.5f * dt * k1Acc;
					//DirectX.Vector2 k2Acc = SMath.CalcCons_Length(				t + 0.5f * dt, pos + 0.5F * dt * k1Vel, k2Vel,
					//    cons_Length[i].N3, out snapped);
					//    //f(t + 0.5f * dt, pos + 0.5f * dt * k1Vel, k2Vel);

					//DirectX.Vector2 k3Vel =										vel + 0.5f * dt * k2Acc;
					//DirectX.Vector2 k3Acc = SMath.CalcCons_Length(				t + 0.5f * dt, pos + 0.5F * dt * k2Vel, k3Vel,
					//    cons_Length[i].N3, out snapped);
					//    // = f(t + 0.5f * dt, pos + 0.5f * dt * k2Vel, k3Vel);
					//DirectX.Vector2 k4Vel =										vel + dt * k3Acc;
					//DirectX.Vector2 k4Acc = SMath.CalcCons_Length(				t + dt, pos + dt * k3Vel, k4Vel,
					//    cons_Length[i].N3, out snapped);

					//pos = (dt / 6.0f) * (k1Vel + 2.0f * k2Vel + 2.0f * k3Vel + k4Vel);
					//vel = (dt / 6.0f) * (k1Acc + 2.0f * k2Acc + 2.0f * k3Acc + k4Acc);

					////float length = vel.Length();
					////vel -= (vel * (1F/length)) * ((length-(Simulation.L_Damping * (pos.X * vel.X + pos.Y * vel.Y) / cons_Length[i].N3) * 0.5F)/length);




					bool snapped;
					constraintForce_1 = SMath.CalcCons_Length(
						particles[cons_Length[i].N1].Position - particles[cons_Length[i].N2].Position,
						particles[cons_Length[i].N1].Velocity - particles[cons_Length[i].N2].Velocity,
						cons_Length[i].N3, out snapped);

                    if (snapped)
                    {
                        cons_Length[i].N3 *= -1;
                        activeConstraints--;
                    }

					//particles[cons_Length[i].N1].Velocity -= vel;
					//particles[cons_Length[i].N2].Velocity += vel;

					//particles[cons_Length[i].N1].Position -= vel;
					//particles[cons_Length[i].N2].Position += vel;


					particles[cons_Length[i].N1].Velocity -= constraintForce_1;
					particles[cons_Length[i].N2].Velocity += constraintForce_1;
				}
            }
            //Draw
            iP = 2;
            for (int i = 0; i < cons_Length.Length; i++)
			{
				if (C_WasSnapped[i]) continue;

                consDraw_polygon[iP] = new DirectX.Vector4(
                    particles[cons_Length[i].N1].Position.X,
                    particles[cons_Length[i].N1].Position.Y, 0, 0);

                consDraw_polygon[iP + 1] = new DirectX.Vector4(
                    particles[cons_Length[i].N2].Position.X,
					particles[cons_Length[i].N2].Position.Y, 0, 0);
				iL += 2;
                iP += 4;
			}
			render.DrawBlurLine(consDraw_polygon, Simulation.C_Constraint_Start, Simulation.C_Constraint_End, Simulation.C_Constraint_AlphaLength);
            render.EndScene();
        }

        private void Interact(float percent, bool repulseCL)
        {
			float mDiffL = ((Simulation.Mouse_Position - Simulation.Mouse_PositionLast).Length() + Simulation.Affect_Radius)/Simulation.Affect_Radius;
			if(mDiffL < 1) mDiffL = 1;

			DirectX.Vector2 mousePercentPosition = Simulation.Mouse_Position - (Simulation.Mouse_Position - Simulation.Mouse_PositionLast) * percent;
            if (Simulation.Mouse_Left || !repulseCL)
            {
				int uParticle = selectedParticle;
				if (!repulseCL) uParticle = GetNearestAtom(mousePercentPosition);
				if (uParticle != -1)
                {
					particles[uParticle].Position = mousePercentPosition;
					if (!repulseCL) particles[uParticle].Velocity = new DirectX.Vector2(100000000000, 100000000000);
					else  particles[uParticle].Velocity = new DirectX.Vector2(0, 0);
                }
            }
			if(repulseCL)
			if (Simulation.Mouse_Right)
			{
				DirectX.Vector2 affect;
				for (int i = 0; i < particles.Length; i++)
				{
					if ((mousePercentPosition - particles[i].Position).LengthSq() > Simulation.Affect_Radius * Simulation.Affect_Radius) continue;

					affect = (mousePercentPosition - particles[i].Position);
					affect.Normalize();
					affect *= Simulation.Affect_Radius - mDiffL;
					
					//if(mDiffL < 1) mDiffL = 1;
					float percentAffectStiffness = Simulation.Affect_Stiffness * mDiffL;

					particles[i].Velocity -= affect * percentAffectStiffness;
				}
			}
        }

        private int GetNearestAtom(DirectX.Vector2 checkLoc)
        {
            if (activeConstraints == 0) return -1;

            float closestDistance = float.PositiveInfinity;
            int closestIndex = -1;

            float currentDistance = float.PositiveInfinity;
            for (int i = 0; i < cons_Length.Length; i++)
            {
                if (cons_Length[i].N3 < 0) continue;
                currentDistance = (particles[cons_Length[i].N1].Position - checkLoc).LengthSq();
                if (currentDistance < closestDistance)
                {
                    closestDistance = currentDistance;
                    closestIndex = cons_Length[i].N1;
                }

                currentDistance = (particles[cons_Length[i].N2].Position - checkLoc).LengthSq();
                if (currentDistance < closestDistance)
                {
                    closestDistance = currentDistance;
                    closestIndex = cons_Length[i].N2;
                }
            }

            return closestIndex;
        }

        #region Events

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

			if (e.KeyCode == Keys.Escape) Close();
			else if (e.KeyCode == Keys.F5) Restart(lastRestartI);
			else if (e.KeyCode == Keys.P) Simulation.Paused = !Simulation.Paused;
			else if (e.KeyCode == Keys.O)
			{
				Simulation.Paused = true;
				UpdateWorld();
				//PaintScreen();
			}
			else if (e.KeyCode == Keys.D1) Restart(1);
			else if (e.KeyCode == Keys.D2) Restart(2);
			else if (e.KeyCode == Keys.D3) Restart(3);
			else if (e.KeyCode == Keys.D4) Restart(4);
			else if (e.KeyCode == Keys.D5) Restart(5);
			else if (e.KeyCode == Keys.D6) Restart(6);
			else if (e.KeyCode == Keys.D7) Restart(7);
			else if (e.KeyCode == Keys.D8) Restart(8);
			else if (e.KeyCode == Keys.D9) Restart(9);
			else if (e.KeyCode == Keys.D0) Restart(0);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.Button == MouseButtons.Left)
            {
                Simulation.Mouse_Left = true;
                selectedParticle = GetNearestAtom(Simulation.Mouse_Position);
            }
            if (e.Button == MouseButtons.Right) Simulation.Mouse_Right = true;
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.Button == MouseButtons.Left) Simulation.Mouse_Left = false;
            if (e.Button == MouseButtons.Right) Simulation.Mouse_Right = false;
        }
		protected override void  OnMouseWheel(MouseEventArgs e)
		{
 			base.OnMouseWheel(e);
			Interact(1, false);
		}

		//protected override void OnMouseMove(MouseEventArgs e)
		//{
		//    Simulation.Mouse_Position = new DirectX.Vector2(e.X, e.Y);
		//}

        private void Tick(object sender, EventArgs e)
        {
            if (!Simulation.Paused)
            {
                UpdateWorld();
                //PaintScreen();
            }
        }

        public static void Main()
        {
            Base program = new Base();
            Application.Run(program);
        }

        #endregion
    }
}
