using System;

namespace SpringSim4
{
    public struct Int_3
    {
        public Int_3(int N1, int N2, float N3)
        {
            this.N1 = N1;
            this.N2 = N2;
            this.N3 = N3;
        }

        public int N1;
        public int N2;
        public float N3;
    }
}
