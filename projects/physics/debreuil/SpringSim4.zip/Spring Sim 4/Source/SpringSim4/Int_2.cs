using System;

namespace SpringSim4
{
    public struct Int_2
    {
        public Int_2(int N1, int N2)
        {
            this.N1 = N1;
            this.N2 = N2;
        }

        public int N1;
        public int N2;
    }
}
