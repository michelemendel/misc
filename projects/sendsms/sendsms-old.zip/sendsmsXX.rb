require 'socket'
require 'pp'

@reJsessionid = /JSESSIONID=(.*);/
@reCmd = /&cmd=(.*)$/
@re302 = /302 Moved Temporarily/



@url 			= "epost.telenor.no"
@request 		= "POST /mobileoffice/ HTTP/1.1\r\n"
@header			= "Host: #{@url}\r\n" +
				  "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.5) Gecko/20041217\r\n" +
				  "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5\r\n" +
				  "Accept-Language: en-us,en;q=0.5\r\n" +
				  "Accept-Encoding: gzip,deflate\r\n" +
				  "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\n" +
				  "Keep-Alive: 300\r\n" +
				  "Proxy-Connection: keep-alive\r\n" +
				  "Content-Type: application/x-www-form-urlencoded\r\n"
@referer		= "Referer: http://epost.telenor.no/mobileoffice/?cmd=logout\r\n"
@stop			= "\r\n"


# LOG IN
def login(cmd)
	paramsLogin	= "cmd=login" +
				  "&userid=mmendel" +
				  "&password=a527ack"
	puts "--- LOGGIN IN"
	sock = TCPSocket.open(@url, 80)
	sock.send(@request+@header+@stop+paramsLogin, 0)
	puts @request+@header+@stop+paramsLogin
	html = sock.read
	jsessionid = getJSessionId(html)
	sock.close
	puts "--- socket closed"
	return jsessionid, html
end

def loginGet(jsessionid)
	#~ request = "GET /mobileoffice/ HTTP/1.1\r\n"
	paramsLogin	= "cmd=init"
				  #~ "&cmd=mail&sub=headers\r\n"
	@cookie = "Cookie: JSESSIONID=#{jsessionid}\r\n"				  
	puts "--- LOGGIN IN"
	sock = TCPSocket.open(@url, 80)
	sock.send(@request+@cookie+@stop+paramsLogin, 0)
	puts @request+@cookie+@stop+paramsLogin
	html = sock.read
	jsessionid = getJSessionId(html)
	sock.close
	puts "--- socket closed"
	return jsessionid, html
end

# SEND SMS
def sendSms(cmd, jsessionid)
	@paramsSend	= "cmd=#{cmd}" +
				  "&recipient=41459590" +
				  "&message=blabla" +
				  "&sub=send"
				  #~ "&smsheader=Fra mmendel@online.no" +
	@cookie = "Cookie: JSESSIONID=#{jsessionid}\r\n"
	puts "--- SENDING SMS"
	sock = TCPSocket.open(@url, 80)
	sock.send(@request+@header+@cookie+@stop+@paramsSend, 0)
	html = sock.read
	sock.close
	puts "--- socket closed"
	return html
end

def getJSessionId(html)
	ret = @reJsessionid.match(html)
	if(ret)
		ret = ret[1]
		puts "jsessionid=#{ret}"
	end
	return ret
end

def getCmd(html)
	ret = @reCmd.match(html)
	if(ret)
		ret = ret[1].chomp
		puts "cmd=#{ret}"
	end
	return ret
end

# RUN PROGRAM
jsessionid, html = login("login")
puts html
if(@re302.match(html))
	html = loginGet(jsessionid)
	puts html
end

#~ res, html = sendSms("sms", jsessionid)
#~ if(@re302.match(html))
	#~ sendSms(getJSessionId(html))
#~ end
