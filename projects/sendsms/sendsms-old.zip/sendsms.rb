require 'socket'

# http://www.faqs.org/rfcs/rfc2616.html

$CRLF = "\r\n"
$SP = " "
$httpVersion = "HTTP/1.1"

#
def post(url, requestURI, headers, cookie, urlParams, requestParams)
    httpSend("POST", url, requestURI, headers, cookie, urlParams, requestParams)
end

#
def get(url, requestURI, headers, cookie, urlParams, requestParams)
    cookie = cookie.empty? ? "" : cookie
    httpSend("GET", url, requestURI, headers, cookie, urlParams, requestParams)
end

#
def httpSend(method, url, requestURI, headers, cookie, urlParams, requestParams)
    requestURI += urlParams.empty? ? "" : "?" + urlParams
    requestLine = method + $SP + requestURI + $SP + $httpVersion
    requestParams = requestParams.empty? ? "" : requestParams.join("&")
    
    header = "Host: #{url}" + $CRLF + headers.join($CRLF)
    header += $CRLF + "Content-Length: #{requestParams.length}"
    header += cookie.empty? ? "" : $CRLF + "Cookie: " + cookie
    request =  requestLine + $CRLF + 
               header + $CRLF + $CRLF +
               requestParams
    
    puts "\n--- REQUEST ---\n#{request}\n--- /REQUEST ---"
    socket = TCPSocket.open(url, 80)
    socket.send(request, 0)
    resp = socket.read()
    socket.close
    #~ puts "\n--- RESPONSE ---\n#{resp}--- /RESPONSE ---\n\n"
    puts "\n--- RESPONSE ---\n#{getHeader(resp)}\n--- /RESPONSE ---\n\n"
    return resp
end

def getHeader(page)
    re = /(HTTP.*Close)/m
    m = page.match(re)
    return m[1] unless !m
end

def getHtml(page)
    re = /(<HTML>.*<\/HTML>)/mi
    m = page.match(re)
    return m[1] unless !m
end

def writeFile(fileName, content)
    File.open(fileName,"w") {|f|
        f.print(getHtml(content))
    }
end

def getErrorMsg(page)
    reLabel = /<td class="errormessage-label">(.*?)</
    reMsg = /<td class="errormessage-text">(.*?)</m
    label = page.match(reLabel)[1]
    msg = page.match(reMsg)[1]
    return "#{label}: #{msg}"
end

url = "epost.telenor.no"
requestURI = "/mobileoffice/"

# POST
header  = [
            #~ "Content-Type: application/x-www-form-urlencoded",
            #~ "User-Agent: RMM",
            #~ "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.5) Gecko/20041217",
            #~ "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,image/jpeg,image/gif;q=0.2,*/*;q=0.1",
            #~ "Accept-Language: en-us,en;q=0.5",
            #~ "Accept-Encoding: gzip,deflate", 
            #~ "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7",
            #~ "Keep-Alive: 3",
            #~ "Proxy-Connection: keep-alive",
            "Connection: close"
          ]

urlParams = "cmd=login&userid=mmendel&password=a527ack"
requestParams = []
resp = post(url, requestURI, header, "", urlParams, requestParams)


# 302-REDIRECT - GET
reParams = /Location: http:\/\/#{url}#{requestURI}(.*)$/
reCookie = /Set-Cookie: (.*);/
reJsessionid = /(;jsessionid=.*)\?/

urlParams = resp.match(reParams)[1].chomp
#~ puts "urlParams=#{urlParams}"
requestParams = []
cookie = resp.scan(reCookie).join(";")
jsessionid = resp.match(reJsessionid)[1].chomp
resp = get(url, requestURI, header, cookie, urlParams, requestParams)
#~ writeFile("temp.html", resp)

# SEND SMS
urlParams = "cmd=sms&smsheader=mmendel&recipient=41459590&message=hej&sub=send"
requestParams = []
resp = post(url, requestURI, header, cookie, urlParams, requestParams)
#~ writeFile("temp.html", resp)
puts getErrorMsg(resp)
