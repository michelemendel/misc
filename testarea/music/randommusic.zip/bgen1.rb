##############################################################################
# Program : bgen1.rb
#
# Description
# -----------
# Random baseline generator
#
# Version : 1.000
# Dated   : 21st July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
# 
# A simple baseline generator that puts out a 4/4 baseline. It is a riff maker
# if you like. The parameters are:
#
#   --length : The length of the required riff in bars. 1 and 2 are good, 4 is
#              a bit long and anything else is just plain weird.
#   --repeat : The number of times you want the riff repeated.
#   --notes  : The notes to make the riff from. Notes are chosen at random.
#   --bpm    : The speed of the piece in beats per minute
#   --output : The file to write the midi compiler file to.
#
# It works like this. Each bar that it generates is made up of 4 potential
# quarter notes what actually happens on a given quarter note is chosen at
# random from a number between 0 and 5.
#
#   0 : The quarter is silent. A quarter rest.
#   1 : The quarter is played as a quarter note.
#   2 : The quarter is played as an eighth note followed by an eighth rest.
#   3 : The quarter is played as an eighth rest followed by an eighth note.
#   4 : The quarter is played as two eighth notes.
#
# Each time the note in question is played it is simply picked from the note
# list that was given.
# 
# I tried this out with eighths and sixteenths instead of quarters and eighth
# and it must be said that it produced far less 'usefull' results.
#
# Version : 1.001
# Dated   : 24th July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Adjusted the code to work with 16 divisions rather than 8 so that the output
# of the drum generator could be married to it.
#
# Problems
# --------
# Doesn't do waltzes.
# The maximum note length is a quarter, longer note lengths will require a
# different implementation.
# Almost nothing by way of error checking.
#
# To do
# -----
# More error checking
##############################################################################

require 'getoptlong'

##############################################################################
# Generate the riff and write it out to the file
##############################################################################

def makepattern(filehandle, length, repeat, notes, bpm)
 pattern = ''
 length.times {
  (0..3).each {|counter|
   x = rand(5)
   if x == 0 then
    # No notes, do nothing
   elsif x == 1 then
    pattern = pattern + " note #{counter*4} #{notes[rand(notes.length)]} quarter\n"
   elsif x == 2 then
    pattern = pattern + " note #{counter*4} #{notes[rand(notes.length)]} eighth\n"
   elsif x == 3 then
    pattern = pattern + " note #{(counter*4)+2} #{notes[rand(notes.length)]} eighth\n"
   else
    pattern = pattern + " note #{counter*4} #{notes[rand(notes.length)]} eighth\n"
    pattern = pattern + " note #{(counter*4)+2} #{notes[rand(notes.length)]} eighth\n"
   end
  }
  pattern = pattern + " bar\n"
 }

 filehandle.print "bpm #{bpm}\n"
 filehandle.print "tempo 4/4\n"
 filehandle.print "divisions 16\n"
 filehandle.print "\n"
 filehandle.print "channel 9\n"
 filehandle.print "repeat #{length * repeat}\n"
 filehandle.print " note  0 acoustic_bass_drum quarter\n"
 filehandle.print " note  4 acoustic_snare     quarter\n"
 filehandle.print " note  8 acoustic_snare     quarter\n"
 filehandle.print " note 12 acoustic_snare     quarter\n"
 filehandle.print " bar\n"
 filehandle.print "endrepeat\n"
 filehandle.print "\n"
 filehandle.print "channel 0\n"
 filehandle.print "instrument acoustic_bass\n"
 filehandle.print "\n"
 filehandle.print "repeat #{repeat}\n"
 filehandle.print pattern
 filehandle.print "endrepeat\n"

 filehandle.print "\n"
 filehandle.print "; Debug\n"
 filehandle.print "; =====\n"
 filehandle.print "; Length = #{length}\n"
 filehandle.print "; Repeat = #{repeat}\n"
 filehandle.print "; Bpm ==== #{bpm}\n"
 filehandle.print "; Notes =="
 notes.each {|n| filehandle.print " #{n}"}
 filehandle.print "\n"
end

##############################################################################
# The mainline code
##############################################################################

opts = GetoptLong.new(
 [ "--length", "-l", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--repeat", "-r", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--notes",  "-n", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--bpm",    "-b", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--output", "-o", GetoptLong::REQUIRED_ARGUMENT ]
)

length = -1
repeat = -1
notes = []
outfile = ''
bpm = -1

opts.each do |opt, arg|
  if opt == "--length" then
   length = arg.to_i
  end

  if opt == "--repeat" then
   repeat = arg.to_i
  end

  if opt == "--notes" then
   notes = arg.split(",")
  end

  if opt == "--output" then
   outfile = arg.inspect.gsub("\"", "")
  end

  if opt == "--bpm" then
   bpm = arg.to_i
  end
end

f = File.new(outfile, "w")
makepattern(f, length, repeat, notes, bpm)
f.close

##############################################################################
# End of the source, end of the file
##############################################################################
