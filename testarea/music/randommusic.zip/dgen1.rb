##############################################################################
# Program : dgen1.rb
#
# Description
# -----------
# A random drum track generator
#
# Version : 1.000
# Dated   : 23rd July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
# 
# An attempt at creating drum tracks from random numbers. This is the best I have
# yet created (althought that is not saying much). The first two attempts sounded
# like a drum kit being thrown down a flight of stairs. The odds were on it
# creating crap lines rather than any halfway decent lines so I had to cheat.
#
# The is less of a random generator (like the baseline generator) and more of a 
# simulation. A drummer has (usually) two hands and two feet. These are the four
# streams you will see in makepattern(). Each bar is made up of 16 divisions, on
# each beat of each division there is a probability of a note being sounded. If
# a note is to be played a drum from those available to that stream is chosen.
# An attempt to simulate at least what is possible for a drummer to play rather
# but it needs some more work on it as it can be rather sparse.
#
#   --length : The length of the required riff in bars. 1 and 2 are good, 4 is
#              a bit long and anything else is just plain weird.
#   --repeat : The number of times you want the riff repeated.
#   --bpm    : The speed of the piece in beats per minute
#   --output : The file to write the midi compiler file to.
# 
# Another approach is called for, unless you have a lot of time to sit through
# the output of this program.
# 
# Problems
# --------
# Almost nothing by way of error checking.
#
# To do
# -----
# More error checking
##############################################################################

require 'getoptlong'

##############################################################################
# Generate the riff and write it out to the file
##############################################################################

def makepattern(filehandle, length, repeat, bpm)
 pattern = ''

 instrumentstreams = Array.new
 instrumentstreams << ['bass_drum_1']
 instrumentstreams << ['open_hi-hat', 'closed_hi-hat']
 instrumentstreams << ['low_floor_tom', 'hi-mid_tom']
 instrumentstreams << ['acoustic_snare', 'low_tom']

 probabilitystreams = Array.new
 probabilitystreams << [.95 , 0 , .2375 , 0 , .475 , 0 , .2375 , 0 , .95 , 0 , .2375 , 0 , .475 , 0 , .2375 , 0]
 probabilitystreams << [.75 , 0 , .1875 , 0 , .375 , 0 , .1875 , 0 , .75 , 0 , .1875 , 0 , .375 , 0 , .1875 , 0]
 probabilitystreams << [.6 , 0 , .2 , 0 , .6 , 0 , .2 , 0 , .6 , 0 , .2 , 0 , .6 , 0 , .2 , 0]
 probabilitystreams << [.2 , 0 , .6 , 0 , .2 , 0 , .6 , 0 , .2 , 0 , .6 , 0 , .2 , 0 , .6 , 0]

 length.times {
  (0..15).each {|counter|
   (0..3).each {|stream|
    if rand <= probabilitystreams[stream][counter] then
     pattern = pattern + " note #{counter} #{instrumentstreams[stream][rand(instrumentstreams[stream].length)]} eighth\n"
    end
   }
  }
  pattern = pattern + " bar\n"
 }

 filehandle.print "bpm #{bpm}\n"
 filehandle.print "tempo 4/4\n"
 filehandle.print "divisions 16\n"
 filehandle.print "\n"
 filehandle.print "channel 9\n"
 filehandle.print "repeat #{repeat}\n"
 filehandle.print pattern
 filehandle.print "endrepeat\n"

 filehandle.print "\n"
 filehandle.print "; Debug\n"
 filehandle.print "; =====\n"
 filehandle.print "; Length = #{length}\n"
 filehandle.print "; Repeat = #{repeat}\n"
 filehandle.print "; Bpm ==== #{bpm}\n"
end

##############################################################################
# The mainline code
##############################################################################

opts = GetoptLong.new(
 [ "--length", "-l", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--repeat", "-r", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--bpm",    "-b", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--output", "-o", GetoptLong::REQUIRED_ARGUMENT ]
)

length = -1
repeat = -1
outfile = ''
bpm = -1

opts.each do |opt, arg|
  if opt == "--length" then
   length = arg.to_i
  end

  if opt == "--repeat" then
   repeat = arg.to_i
  end

  if opt == "--output" then
   outfile = arg.inspect.gsub("\"", "")
  end

  if opt == "--bpm" then
   bpm = arg.to_i
  end
end

f = File.new(outfile, "w")
makepattern(f, length, repeat, bpm)
f.close

##############################################################################
# End of the source, end of the file
##############################################################################
