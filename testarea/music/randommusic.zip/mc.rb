#!/usr/bin/ruby

require 'getoptlong'

##############################################################################
# Program : mc
#
# Description
# -----------
# The MIDI compiler
#
# Version : 1.000
# Dated   : 4th July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
# 
# Initial version for Ruby and OO methods. Quite nice but I can't seem to get
# the comments in the input files to be processed correctly so there are no
# comments for the present. Lacks some (very) basic error checking.
#
# Version : 1.001
# Dated   : 17th July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# The program can now handle comments in the input file if they are preceeded
# with a semi colon ; like this. Progress huh.
# 
# Version : 1.002
# Dated   : 28th July 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# NoteEvent now tackles the on and off volume of a note. From looking at Cubase
# it would seem the volume is 64 for all instruments on and off except for
# drumes which is 120 for the on volume. It's nice to have tidied that up.
#
# To do
# -----
# More error checking
##############################################################################

##############################################################################
# The NoteEvent class
##############################################################################

class NoteEvent
 include Comparable

 def initialize(onoroff, delta, channel, pitch)
  @delta = delta
  if channel == 9 and onoroff == 'on' then
   volume = 120
  else
   volume = 64
  end
  if onoroff == 'on' then
   channel = channel + 144
  else
   channel = channel + 128
  end
  @data = [channel, pitch, volume].pack('ccc')
 end

 def <=>(other)
  self.delta <=> other.delta
 end

 def delta
  @delta
 end
  
 def data
  @data
 end
end

##############################################################################
# The MidiCompiler class
##############################################################################

class MidiCompiler
 def initialize
  # These variables are constant set only once

  @tempo_a  = -1
  @tempo_b = -1
  @bpm = -1
  @divisions = -1

  # These variables change on a track by track basis

  @channel = -1
  @instrument = -1

  # Part of the header

  @ticks = -1
  @tracks = -1

  # Keeping track of the output

  @offset = 0
  @eventlist = Array.new
  @stringofdata = ''
  @maxdelta = 0

  @instrumentnames = Hash.new
  @instrumentnames['accoridan'] = 22
  @instrumentnames['acoustic_bass'] = 33
  @instrumentnames['acoustic_grand'] = 1
  @instrumentnames['acoustic_guitar(nylon)'] = 25
  @instrumentnames['acoustic_guitar(steel)'] = 26
  @instrumentnames['agogo'] = 114
  @instrumentnames['alto_sax'] = 66
  @instrumentnames['applause'] = 127
  @instrumentnames['bagpipe'] = 110
  @instrumentnames['banjo'] = 106
  @instrumentnames['baritone_sax'] = 68
  @instrumentnames['bassoon'] = 71
  @instrumentnames['bird_tweet'] = 124
  @instrumentnames['blown_bottle'] = 77
  @instrumentnames['brass_section'] = 62
  @instrumentnames['breath_noise'] = 122
  @instrumentnames['bright_acoustic'] = 2
  @instrumentnames['celesta'] = 9
  @instrumentnames['cello'] = 43
  @instrumentnames['choir_aahs'] = 53
  @instrumentnames['church_organ'] = 20
  @instrumentnames['clarinet'] = 72
  @instrumentnames['clav'] = 8
  @instrumentnames['contrabass'] = 44
  @instrumentnames['distortion_guitar'] = 31
  @instrumentnames['drawbar_organ'] = 17
  @instrumentnames['dulcimer'] = 16
  @instrumentnames['electric_bass(finger)'] = 34
  @instrumentnames['electric_bass(pick)'] = 35
  @instrumentnames['electric_grand'] = 3
  @instrumentnames['electric_guitar(clean)'] = 28
  @instrumentnames['electric_guitar(jazz)'] = 27
  @instrumentnames['electric_guitar(muted)'] = 29
  @instrumentnames['electric_piano_1'] = 5
  @instrumentnames['electric_piano_2'] = 6
  @instrumentnames['english_horn'] = 70
  @instrumentnames['fiddle'] = 111
  @instrumentnames['flute'] = 74
  @instrumentnames['french_horn'] = 61
  @instrumentnames['fretless_bass'] = 36
  @instrumentnames['fx_1_(rain)'] = 97
  @instrumentnames['fx_2_(soundtrack)'] = 98
  @instrumentnames['fx_3_(crystal)'] = 99
  @instrumentnames['fx_4_(atmosphere)'] = 100
  @instrumentnames['fx_5_(brightness)'] = 101
  @instrumentnames['fx_6_(goblins)'] = 102
  @instrumentnames['fx_7_(echoes)'] = 103
  @instrumentnames['fx_8_(sci-fi)'] = 104
  @instrumentnames['glockenspiel'] = 10
  @instrumentnames['guitar_fret_noise'] = 121
  @instrumentnames['guitar_harmonics'] = 32
  @instrumentnames['gunshot'] = 128
  @instrumentnames['harmonica'] = 23
  @instrumentnames['harpsichord'] = 7
  @instrumentnames['helicopter'] = 126
  @instrumentnames['honky-tonk'] = 4
  @instrumentnames['kalimba'] = 109
  @instrumentnames['koto'] = 108
  @instrumentnames['lead_1_(square)'] = 81
  @instrumentnames['lead_2_(sawtooth)'] = 82
  @instrumentnames['lead_3_(calliope)'] = 83
  @instrumentnames['lead_4_(chiff)'] = 84
  @instrumentnames['lead_5_(charang)'] = 85
  @instrumentnames['lead_6_(voice)'] = 86
  @instrumentnames['lead_7_(fifths)'] = 87
  @instrumentnames['lead_8_(bass+lead)'] = 88
  @instrumentnames['marimba'] = 13
  @instrumentnames['melodic_tom'] = 118
  @instrumentnames['music_box'] = 11
  @instrumentnames['muted_trumpet'] = 60
  @instrumentnames['oboe'] = 69
  @instrumentnames['ocarina'] = 80
  @instrumentnames['orchestra_hit'] = 56
  @instrumentnames['orchestral_strings'] = 47
  @instrumentnames['overdriven_guitar'] = 30
  @instrumentnames['pad_1_(new_age)'] = 89
  @instrumentnames['pad_2_(warm)'] = 90
  @instrumentnames['pad_3_(polysynth)'] = 91
  @instrumentnames['pad_4_(choir)'] = 92
  @instrumentnames['pad_5_(bowed)'] = 93
  @instrumentnames['pad_6_(metallic)'] = 94
  @instrumentnames['pad_7_(halo)'] = 95
  @instrumentnames['pad_8_(sweep)'] = 96
  @instrumentnames['pan_flute'] = 76
  @instrumentnames['percussive_organ'] = 18
  @instrumentnames['piccolo'] = 73
  @instrumentnames['pizzicato_strings'] = 46
  @instrumentnames['recorder'] = 75
  @instrumentnames['reed_organ'] = 21
  @instrumentnames['reverse_cymbal'] = 120
  @instrumentnames['rock_organ'] = 19
  @instrumentnames['seashore'] = 123
  @instrumentnames['shamisen'] = 107
  @instrumentnames['shanai'] = 112
  @instrumentnames['sitar'] = 105
  @instrumentnames['skakuhachi'] = 78
  @instrumentnames['slap_bass_1'] = 37
  @instrumentnames['slap_bass_2'] = 38
  @instrumentnames['soprano_sax'] = 65
  @instrumentnames['steel_drums'] = 115
  @instrumentnames['string_ensemble_1'] = 49
  @instrumentnames['string_ensemble_2'] = 50
  @instrumentnames['synth_bass_1'] = 39
  @instrumentnames['synth_bass_2'] = 40
  @instrumentnames['synth_drum'] = 119
  @instrumentnames['synth_voice'] = 55
  @instrumentnames['synthbrass_1'] = 63
  @instrumentnames['synthbrass_2'] = 64
  @instrumentnames['synthstrings_1'] = 51
  @instrumentnames['synthstrings_2'] = 52
  @instrumentnames['taiko_drum'] = 117
  @instrumentnames['tango_accordian'] = 24
  @instrumentnames['telephone_ring'] = 125
  @instrumentnames['tenor_sax'] = 67
  @instrumentnames['timpani'] = 48
  @instrumentnames['tinkle_bell'] = 113
  @instrumentnames['tremolo_strings'] = 45
  @instrumentnames['trombone'] = 58
  @instrumentnames['trumpet'] = 57
  @instrumentnames['tuba'] = 59
  @instrumentnames['tubular_bells'] = 15
  @instrumentnames['vibraphone'] = 12
  @instrumentnames['viola'] = 42
  @instrumentnames['violin'] = 41
  @instrumentnames['voice_oohs'] = 54
  @instrumentnames['whistle'] = 79
  @instrumentnames['woodblock'] = 116
  @instrumentnames['xylophone'] = 14

  @drumnotenames = Hash.new
  @drumnotenames['acoustic_bass_drum'] = 35
  @drumnotenames['acoustic_snare'] = 38
  @drumnotenames['bass_drum_1'] = 36
  @drumnotenames['cabasa'] = 69
  @drumnotenames['chinese_cymbal'] = 52
  @drumnotenames['claves'] = 75
  @drumnotenames['closed_hi-hat'] = 42
  @drumnotenames['cowbell'] = 56
  @drumnotenames['crash_cymbal_1'] = 49
  @drumnotenames['crash_cymbal_2'] = 57
  @drumnotenames['electric_snare'] = 40
  @drumnotenames['hand_clap'] = 39
  @drumnotenames['hi-mid_tom'] = 48
  @drumnotenames['hi_bongo'] = 60
  @drumnotenames['hi_wood_block'] = 76
  @drumnotenames['high_agogo'] = 67
  @drumnotenames['high_floor_tom'] = 43
  @drumnotenames['high_timbale'] = 65
  @drumnotenames['high_tom'] = 50
  @drumnotenames['long_guiro'] = 74
  @drumnotenames['long_whistle'] = 72
  @drumnotenames['low-mid_tom'] = 47
  @drumnotenames['low_agogo'] = 68
  @drumnotenames['low_bongo'] = 61
  @drumnotenames['low_conga'] = 64
  @drumnotenames['low_floor_tom'] = 41
  @drumnotenames['low_timbale'] = 66
  @drumnotenames['low_tom'] = 45
  @drumnotenames['low_wood_block'] = 77
  @drumnotenames['maracas'] = 70
  @drumnotenames['mute_cuica'] = 78
  @drumnotenames['mute_hi_conga'] = 62
  @drumnotenames['mute_triangle'] = 80
  @drumnotenames['open_cuica'] = 79
  @drumnotenames['open_hi-hat'] = 46
  @drumnotenames['open_hi_conga'] = 63
  @drumnotenames['open_triangle'] = 81
  @drumnotenames['pedal_hi-hat'] = 44
  @drumnotenames['ride_bell'] = 53
  @drumnotenames['ride_cymbal_1'] = 51
  @drumnotenames['ride_cymbal_2'] = 59
  @drumnotenames['short_guiro'] = 73
  @drumnotenames['short_whistle'] = 71
  @drumnotenames['side_stick'] = 37
  @drumnotenames['splash_cymbal'] = 55
  @drumnotenames['tambourine'] = 54
  @drumnotenames['vibraslap'] = 58

  @notenames = Hash.new
  @notenames['c0'] = 0
  @notenames['c#0'] = 1
  @notenames['d0'] = 2
  @notenames['d#0'] = 3
  @notenames['e0'] = 4
  @notenames['f0'] = 5
  @notenames['f#0'] = 6
  @notenames['g0'] = 7
  @notenames['g#0'] = 8
  @notenames['a0'] = 9
  @notenames['a#0'] = 10
  @notenames['b0'] = 11
  @notenames['c1'] = 12
  @notenames['c#1'] = 13
  @notenames['d1'] = 14
  @notenames['d#1'] = 15
  @notenames['e1'] = 16
  @notenames['f1'] = 17
  @notenames['f#1'] = 18
  @notenames['g1'] = 19
  @notenames['g#1'] = 20
  @notenames['a1'] = 21
  @notenames['a#1'] = 22
  @notenames['b1'] = 23
  @notenames['c2'] = 24
  @notenames['c#2'] = 25
  @notenames['d2'] = 26
  @notenames['d#2'] = 27
  @notenames['e2'] = 28
  @notenames['f2'] = 29
  @notenames['f#2'] = 30
  @notenames['g2'] = 31
  @notenames['g#2'] = 32
  @notenames['a2'] = 33
  @notenames['a#2'] = 34
  @notenames['b2'] = 35
  @notenames['c3'] = 36
  @notenames['c#3'] = 37
  @notenames['d3'] = 38
  @notenames['d#3'] = 39
  @notenames['e3'] = 40
  @notenames['f3'] = 41
  @notenames['f#3'] = 42
  @notenames['g3'] = 43
  @notenames['g#3'] = 44
  @notenames['a3'] = 45
  @notenames['a#3'] = 46
  @notenames['b3'] = 47
  @notenames['c4'] = 48
  @notenames['c#4'] = 49
  @notenames['d4'] = 50
  @notenames['d#4'] = 51
  @notenames['e4'] = 52
  @notenames['f4'] = 53
  @notenames['f#4'] = 54
  @notenames['g4'] = 55
  @notenames['g#4'] = 56
  @notenames['a4'] = 57
  @notenames['a#4'] = 58
  @notenames['b4'] = 59
  @notenames['c5'] = 60
  @notenames['c#5'] = 61
  @notenames['d5'] = 62
  @notenames['d#5'] = 63
  @notenames['e5'] = 64
  @notenames['f5'] = 65
  @notenames['f#5'] = 66
  @notenames['g5'] = 67
  @notenames['g#5'] = 68
  @notenames['a5'] = 69
  @notenames['a#5'] = 70
  @notenames['b5'] = 71
  @notenames['c6'] = 72
  @notenames['c#6'] = 73
  @notenames['d6'] = 74
  @notenames['d#6'] = 75
  @notenames['e6'] = 76
  @notenames['f6'] = 77
  @notenames['f#6'] = 78
  @notenames['g6'] = 79
  @notenames['g#6'] = 80
  @notenames['a6'] = 81
  @notenames['a#6'] = 82
  @notenames['b6'] = 83
  @notenames['c7'] = 84
  @notenames['c#7'] = 85
  @notenames['d7'] = 86
  @notenames['d#7'] = 87
  @notenames['e7'] = 88
  @notenames['f7'] = 89
  @notenames['f#7'] = 90
  @notenames['g7'] = 91
  @notenames['g#7'] = 92
  @notenames['a7'] = 93
  @notenames['a#7'] = 94
  @notenames['b7'] = 95
  @notenames['c8'] = 96
  @notenames['c#8'] = 97
  @notenames['d8'] = 98
  @notenames['d#8'] = 99
  @notenames['e8'] = 100
  @notenames['f8'] = 101
  @notenames['f#8'] = 102
  @notenames['g8'] = 103
  @notenames['g#8'] = 104
  @notenames['a8'] = 105
  @notenames['a#8'] = 106
  @notenames['b8'] = 107
  @notenames['c9'] = 108
  @notenames['c#9'] = 109
  @notenames['d9'] = 110
  @notenames['d#9'] = 111
  @notenames['e9'] = 112
  @notenames['f9'] = 113
  @notenames['f#9'] = 114
  @notenames['g9'] = 115
  @notenames['g#9'] = 116
  @notenames['a9'] = 117
  @notenames['a#9'] = 118
  @notenames['b9'] = 119
  @notenames['c10'] = 120
  @notenames['c#10'] = 121
  @notenames['d10'] = 122
  @notenames['d#10'] = 123
  @notenames['e10'] = 124
  @notenames['f10'] = 125
  @notenames['f#10'] = 126
  @notenames['g10'] = 127
 end

 ##############################################################################
 # Private utility functions
 ##############################################################################

 private

 def panic(a)
  print "ERROR:#{a}\n"
  exit
 end

 def numeric(text)
  text.each('') {|char|
   if char < '0' or char > '9' then
    return false
   end
  }
  return true
 end

 def notevalue(note)
  if @channel != 9 then
   # A non drum channel

   if numeric(note) then
    note = note.to_i
    if @notenames.has_value?(note) then
     return note
    else      
     panic("notevalue:note out of range [#{note}]")
    end
   else
    if @notenames.has_key?(note) then
     return @notenames[note]
    else      
     panic("notevalue:note out of range [#{note}]")
    end
   end
  else
   # The drum channel

   if numeric(note) then
    note = note.to_i
    if @drumnotenames.has_value?(note) then
     return note
    else      
     panic("notevalue:note out of range [#{note}]")
    end
   else
    if @drumnotenames.has_key?(note) then
     return @drumnotenames[note]
    else      
     panic("notevalue:note out of range [#{note}]")
    end
   end
  end
 end

 def notelength(text)
  if text == '1' or text == 'whole' then
   return @ticks * 4
  elsif text == '2' or text == 'half' then
   return @ticks * 2
  elsif text == '4' or text == 'quarter' then
   return @ticks
  elsif text == '8' or text == 'eighth' then
   return @ticks / 2
  elsif text == '16' or text == 'sixteenth' then
   return @ticks / 4
  else
   panic("notelength:unknown length [#{text}]")
  end
 end

 def createdwd(data,size)
  tempdata = [data].pack("i").reverse
  if size < tempdata.length then
   tempdata = tempdata[-size,size]
  end
  return tempdata
 end

 def createdelta(value)
  lda = 0
  ldb = 0
  lsc = ''

  lda = value
  ldb = lda & 127
  lsc = [ldb].pack("c")
  lda = lda >> 7

  while lda > 0 do
    ldb = lda & 127
    lsc = [ldb + 128].pack("c") + lsc
    lda = lda >> 7
  end

  return lsc
 end

 def writedata
  tempdata = ''
  olddelta = 0
  newdelta = 0
  reldelta = 0

  # set the instrument for a non drum channel
  if @channel != 9 then
    tempdata = tempdata + [0, (192 + @channel), @instrument].pack("ccc")
  end

  @eventlist.sort.each{|event|
   newdelta = event.delta
   reldelta = newdelta - olddelta
   tempdata = tempdata + createdelta(reldelta)
   tempdata = tempdata + event.data
   olddelta = newdelta
  }
  # Add the end of track marker
  tempdata = tempdata + [0, 255, 47, 0].pack("cccc")
  @eventlist.clear
  @tracks = @tracks + 1

  tempdata = 'MTrk' + createdwd(tempdata.length,4) + tempdata

  @stringofdata = @stringofdata + tempdata

  if newdelta > @maxdelta then
   @maxdelta = newdelta
  end
  @offset = 0
 end

 def writeitallout
  tempdata = ''

  # Prefix stringofdata with a dummy track to set the tempo
  tempdata = tempdata + [0, 255, 88, 4, @tempo_a, Math.sqrt(@tempo_b).to_i, 24, 8].pack("cccccccc")
  tempdata = tempdata + [0, 255, 81, 3].pack("cccc") + createdwd(60000000/@bpm,3)
  tempdata = tempdata + createdelta(@maxdelta) + [255, 47, 0].pack("ccc")

  tempdata = "MTrk" + createdwd(tempdata.length,4) + tempdata

  @stringofdata = tempdata + @stringofdata
  tempdata = ''

  @tracks = @tracks + 1
  # Prefix stringofdata with a header specifying tracks etc

  tempdata = tempdata + "MThd" + createdwd(6,4) + createdwd(1,2) + createdwd(@tracks, 2) + createdwd(@ticks,2)
  @stringofdata = tempdata + @stringofdata
 end

 ##############################################################################
 # Public functions
 ##############################################################################

 public

 def finished
  writedata()
  writeitallout()

  return @stringofdata
 end

 def bpm=(c)
  if @bpm == -1 then
   if numeric(c) then
    @bpm = c.to_i
   else
    panic("dobpm:non numeric argument [#{text}]")
   end
  else
   call panic("dobpm:command already actioned")
  end
 end

 def tempo=(c)
  if @tempo_a == -1 then
   (ta, tb) = c.split('/')
   if numeric(ta) and numeric(tb) then
    @tempo_a = ta.to_i
    @tempo_b = tb.to_i
   else
    panic("dotempo:unknown data [#{c}]")
   end
  else
   panic("dotempo:command already actioned")
  end
 end

 def divisions=(c)
  if @divisions == -1 then
   if numeric(c) then
    @divisions = c.to_i
   else
    panic("dodivisions:non numeric argument [#{c}]")
   end
  else
   panic("dodivisions:command already actioned")
  end
 end

 def channel=(c)
  if @tempo_a != -1 and @tempo_b != -1 and @bpm != -1 and @divisions != -1 then
   if @channel == -1 then
    @ticks = 96 * @tempo_a * (4 / @tempo_b)
    @tracks = 0
    @barincrement = @ticks * 4 * (@tempo_a / @tempo_b)
    @divisionincrement = @barincrement / @divisions
   else
    writedata()
   end

   if c.length > 0 then
    if numeric(c) then
     @channel = c.to_i
    else
     panic("dochannel:non numeric argument [#{c}]")
    end
   else
    panic("dochannel:no data for command")
   end
  else
   panic("main:globals not set")
  end
 end

 def instrument=(c)
  if @channel != 9 then
   if numeric(c) then
    x = c.to_i
    if 1 <= x and x <= 128 then
     @instrument = x
    else
     panic("instrumentname:instrument number out of range [#{c}]")
    end
   else
    if @instrumentnames.has_key?(c) then
     @instrument = @instrumentnames[c]
    else
     panic("instrumentname:unknown instrument [#{c}]")
    end
   end
  else
   panic("instrumentname:no instrument required for drums (channel 9)")
  end
 end

 def bar
  @offset = @offset + @barincrement
 end

 def note(position, pitch, length)
  if numeric(position) then
   curpos = @offset + (position.to_i * @divisionincrement)
   @eventlist << NoteEvent.new('on',  curpos,                      @channel, notevalue(pitch))
   @eventlist << NoteEvent.new('off', curpos + notelength(length), @channel, notevalue(pitch))
  else
   panic("donote:non numeric argument [#{position}")
  end
 end

end

##############################################################################
# Start of the subs
##############################################################################

def mainloop(infile, outfile)
 mc = MidiCompiler.new

 infile.each {|line|
  l = line.gsub(/;.*/,'').chomp.downcase.split(' ')

  if l.length == 2 and l[0] == 'tempo' then
   mc.tempo = l[1]
  elsif l.length == 2 and l[0] == 'bpm' then
   mc.bpm = l[1]
  elsif l.length == 2 and l[0] == 'divisions' then
   mc.divisions = l[1]
  elsif l.length == 2 and l[0] == 'channel' then
   mc.channel = l[1]
  elsif l.length == 2 and l[0] == 'instrument' then
   mc.instrument = l[1]
  elsif l.length == 1 and l[0] == 'bar' then
   mc.bar
  elsif l.length == 4 and l[0] == 'note' then
   mc.note(l[1], l[2], l[3])
  elsif l.length == 0 then
   # Skip the blank lines
  else
   print "unknown command or number of arguments [#{line.chomp}]\n"
  end
 }

 outfile.print mc.finished
end

##############################################################################
# End of the subs and start of the main code
##############################################################################

opts = GetoptLong.new(
 [ "--input",  "-i", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--output", "-o", GetoptLong::REQUIRED_ARGUMENT ]
)

infile = ''
outfile = ''

opts.each do |opt, arg|
  if opt == "--input" then
   infile  = arg.inspect.gsub("\"", "")
  end

  if opt == "--output" then
   outfile = arg.inspect.gsub("\"", "")
  end
end

f1 = File.new(infile, "r")
f2 = File.new(outfile, "wb")
mainloop(f1, f2)
f1.close
f2.close

##############################################################################
# End of the main code, end of the source
##############################################################################
