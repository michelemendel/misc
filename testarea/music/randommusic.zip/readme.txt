Midi Compiler Input file format
-------------------------------

It's all case insensitive!

The header of the file begins with some setup information.

BPM 180
TEMPO 4/4
DIVISIONS 16

The first two should be self explanatory. I've used most normal
BPMs and the system seems to work fine. The tempo can be any a/b
format that is accepted by the midi file format. This means that
the B portion will be stored as a square root of the input value
and thus must be able to be square rooted (or whatever).

I've done most of my work in 4/4 time and some experimenting with
3/4 time. They seem to work but if you notice strange things 
happening in different tempos I will look into it.

The divisions are how we split up the bar. In this case into 16 
points numbered from 0 to 15. Divisions can be any number you like.

Then we come to the track specific data. Each track starts with the
midi channel that it is to be played on. There are 16 midi channels
numbered 0 to 15. We can use each channel as many times as we like.
Note however that the numbering 0 to 15 is how the file stores the
numbers, they are normally refered to as 1 to 16. Thus for us the 
drums are on channel 9 and not their normal 10.

CHANNEL 0
INSTRUMENT ACOUSTIC_BASS

The channel is followed by the instrument to be played for all channels
except channel 9 which, at present, defaults to the standard drum kit.
The instrument name from the list below or the number can be used.

NOTE  0 e3 eighth
NOTE  2 d3 eighth
NOTE  4 g3 quarter
NOTE  8 f3 eighth
NOTE 12 e2 eighth
NOTE 14 e3 eighth

BAR

NOTE  2 b2 eighth
NOTE  8 c3 quarter

BAR

What follows next is the notes. The first command is note, followed by
division that it is played on, these can occur in any order as they will
be sorted by the compiler. Next follows the note, this again is the 
standard midi notes (see the table below) or their numbers, 0 - 127.
Finally we have the notes duration in either word or numeric form.

 Name      | Value
 ----------+------
 whole     |  1
 half      |  2
 quarter   |  4
 eighth    |  8
 sixteenth | 16

Each bar ends with the word BAR (except perhaps the last bar of a track).
An empty bar would be:

; ... some notes
BAR
BAR
; ... more notes

The division upon which a note is played is, like the divisions command 
itself, an integer - although this is likely to change so we can have 
triplets and groove and all that fine stuff.

Drums are the same except that drums have their own, smaller, set of drum
note names and values. See the table below. Drum note names are used only 
on drums tracks (channel 9) and all other tracks (all channels except 9) 
use the full note/octave table.

Macro commands
--------------
To help writing scores there are three extra commands. The REPEAT .. ENDREPEAT
pair repeats its contents howmany times is specified.

REPEAT 16
 note  0 acoustic_bass_drum quarter
 note  4 acoustic_snare     quarter
 note  8 acoustic_snare     quarter
 note 12 acoustic_snare     quarter
 bar
ENDREPEAT

The PATTERN .. ENDPATTERN records everything inside it and stores it under the 
name given to it.

PATTERN banana
 note 0 e3 eighth
 note 2 d3 eighth
 note 4 g3 quarter
 note 8 f3 eighth
 note 12 e2 eighth
 note 14 e3 eighth
 bar
 note 2 b2 eighth
 note 8 c3 quarter
 bar
ENDPATTERN

The PLAY command expands a previously recorded pattern at that point in the score.
Thus:

PLAY banana

Will write out the stored pattern named banana.


Instrument Names and their numbers
----------------------------------

 accoridan                 22
 acoustic_bass             33
 acoustic_grand             1
 acoustic_guitar(nylon)    25
 acoustic_guitar(steel)    26
 agogo                    114
 alto_sax                  66
 applause                 127
 bagpipe                  110
 banjo                    106
 baritone_sax              68
 bassoon                   71
 bird_tweet               124
 blown_bottle              77
 brass_section             62
 breath_noise             122
 bright_acoustic            2
 celesta                    9
 cello                     43
 choir_aahs                53
 church_organ              20
 clarinet                  72
 clav                       8
 contrabass                44
 distortion_guitar         31
 drawbar_organ             17
 dulcimer                  16
 electric_bass(finger)     34
 electric_bass(pick)       35
 electric_grand             3
 electric_guitar(clean)    28
 electric_guitar(jazz)     27
 electric_guitar(muted)    29
 electric_piano_1           5
 electric_piano_2           6
 english_horn              70
 fiddle                   111
 flute                     74
 french_horn               61
 fretless_bass             36
 fx_1_(rain)               97
 fx_2_(soundtrack)         98
 fx_3_(crystal)            99
 fx_4_(atmosphere)        100
 fx_5_(brightness)        101
 fx_6_(goblins)           102
 fx_7_(echoes)            103
 fx_8_(sci-fi)            104
 glockenspiel              10
 guitar_fret_noise        121
 guitar_harmonics          32
 gunshot                  128
 harmonica                 23
 harpsichord                7
 helicopter               126
 honky-tonk                 4
 kalimba                  109
 koto                     108
 lead_1_(square)           81
 lead_2_(sawtooth)         82
 lead_3_(calliope)         83
 lead_4_(chiff)            84
 lead_5_(charang)          85
 lead_6_(voice)            86
 lead_7_(fifths)           87
 lead_8_(bass+lead)        88
 marimba                   13
 melodic_tom              118
 music_box                 11
 muted_trumpet             60
 oboe                      69
 ocarina                   80
 orchestra_hit             56
 orchestral_strings        47
 overdriven_guitar         30
 pad_1_(new_age)           89
 pad_2_(warm)              90
 pad_3_(polysynth)         91
 pad_4_(choir)             92
 pad_5_(bowed)             93
 pad_6_(metallic)          94
 pad_7_(halo)              95
 pad_8_(sweep)             96
 pan_flute                 76
 percussive_organ          18
 piccolo                   73
 pizzicato_strings         46
 recorder                  75
 reed_organ                21
 reverse_cymbal           120
 rock_organ                19
 seashore                 123
 shamisen                 107
 shanai                   112
 sitar                    105
 skakuhachi                78
 slap_bass_1               37
 slap_bass_2               38
 soprano_sax               65
 steel_drums              115
 string_ensemble_1         49
 string_ensemble_2         50
 synth_bass_1              39
 synth_bass_2              40
 synth_drum               119
 synth_voice               55
 synthbrass_1              63
 synthbrass_2              64
 synthstrings_1            51
 synthstrings_2            52
 taiko_drum               117
 tango_accordian           24
 telephone_ring           125
 tenor_sax                 67
 timpani                   48
 tinkle_bell              113
 tremolo_strings           45
 trombone                  58
 trumpet                   57
 tuba                      59
 tubular_bells             15
 vibraphone                12
 viola                     42
 violin                    41
 voice_oohs                54
 whistle                   79
 woodblock                116 
 xylophone                 14

Notes and their numbers
-----------------------

Octave||                     Note Numbers
   #  ||
      || C   | C#  | D   | D#  | E   | F   | F#  | G   | G#  | A   | A#  | B
-----------------------------------------------------------------------------
   0  ||   0 |   1 |   2 |   3 |   4 |   5 |   6 |   7 |   8 |   9 |  10 | 11
   1  ||  12 |  13 |  14 |  15 |  16 |  17 |  18 |  19 |  20 |  21 |  22 | 23
   2  ||  24 |  25 |  26 |  27 |  28 |  29 |  30 |  31 |  32 |  33 |  34 | 35
   3  ||  36 |  37 |  38 |  39 |  40 |  41 |  42 |  43 |  44 |  45 |  46 | 47
   4  ||  48 |  49 |  50 |  51 |  52 |  53 |  54 |  55 |  56 |  57 |  58 | 59
   5  ||  60 |  61 |  62 |  63 |  64 |  65 |  66 |  67 |  68 |  69 |  70 | 71
   6  ||  72 |  73 |  74 |  75 |  76 |  77 |  78 |  79 |  80 |  81 |  82 | 83
   7  ||  84 |  85 |  86 |  87 |  88 |  89 |  90 |  91 |  92 |  93 |  94 | 95
   8  ||  96 |  97 |  98 |  99 | 100 | 101 | 102 | 103 | 104 | 105 | 106 | 107
   9  || 108 | 109 | 110 | 111 | 112 | 113 | 114 | 115 | 116 | 117 | 118 | 119
  10  || 120 | 121 | 122 | 123 | 124 | 125 | 126 | 127 |


Drum note names and their values
--------------------------------

 acoustic_bass_drum      35
 acoustic_snare          38
 bass_drum_1             36
 cabasa                  69
 chinese_cymbal          52
 claves                  75
 closed_hi-hat           42
 cowbell                 56
 crash_cymbal_1          49
 crash_cymbal_2          57
 electric_snare          40
 hand_clap               39
 hi-mid_tom              48
 hi_bongo                60
 hi_wood_block           76
 high_agogo              67
 high_floor_tom          43
 high_timbale            65
 high_tom                50
 long_guiro              74
 long_whistle            72
 low-mid_tom             47
 low_agogo               68
 low_bongo               61
 low_conga               64
 low_floor_tom           41
 low_timbale             66
 low_tom                 45
 low_wood_block          77
 maracas                 70
 mute_cuica              78
 mute_hi_conga           62
 mute_triangle           80
 open_cuica              79
 open_hi-hat             46
 open_hi_conga           63
 open_triangle           81
 pedal_hi-hat            44
 ride_bell               53
 ride_cymbal_1           51
 ride_cymbal_2           59
 short_guiro             73
 short_whistle           71
 side_stick              37
 splash_cymbal           55
 tambourine              54
 vibraslap               58

To do
-----
More error checking in the programs.
Drum Kits!
