#!/usr/bin/ruby

require 'getoptlong'

##############################################################################
# Program : mcpp
#
# Description
# -----------
# A preprocessor for the MIDI compiler. This implements the pattern and play 
# commands which are in effect macro record and playback. There is also a
# repeat command which this program unrolls
#
# Version : 1.000
# Dated   : 27th June 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
# 
# Initial version. No real error checking
#
# To do
# -----
# Some sort of error checking would be nice!
##############################################################################

##############################################################################
# Start of the subs
##############################################################################

def dorepeat(filehandle, times)
 data = Array.new

 filehandle.each {|line|
  (a, b, c) = line.chomp.downcase.split(' ', 3)
  if a == 'repeat' then
   # does the repeat have a value, is it a number?
   data << dorepeat(filehandle, b.to_i)
  elsif a == 'endrepeat' then
   break
  else
   data << line
  end
 }

 return (data * times).flatten
end

def dopattern(rawdata)
 data = Array.new
 patternname = ''
 patterndata = Array.new
 patterns = Hash.new

 rawdata.each {|line|
  (a, b, c) = line.to_s.chomp.downcase.split(' ', 3)
  if a == 'pattern' then
   # does the pattern have a name, has it already been used?
   patternname = b
  elsif a == 'endpattern' then
   patterns[patternname] = "#{patterndata}"
   patternname = ''
   patterndata.clear
  elsif a == 'play' then
   # does the play have a name, does that name exist?
   data << patterns[b]
  else
   if patternname == '' then
    data << line
   else
    patterndata << line
   end
  end
 }

 return data
end

##############################################################################
# End of the subs and start of the main code
##############################################################################

opts = GetoptLong.new(
 [ "--input",  "-i", GetoptLong::REQUIRED_ARGUMENT ],
 [ "--output", "-o", GetoptLong::REQUIRED_ARGUMENT ]
)

infile = ''
outfile = ''

opts.each do |opt, arg|
  if opt == "--input" then
   infile  = arg.inspect.gsub("\"", "")
  end

  if opt == "--output" then
   outfile = arg.inspect.gsub("\"", "")
  end
end

f1 = File.new(infile, "r")
f2 = File.new(outfile, "w")
f2.print dopattern(dorepeat(f1,1))
f1.close
f2.close

##############################################################################
# End of the main code, end of the source
##############################################################################
