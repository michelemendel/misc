#!/usr/bin/ruby

################################################################################
# Class   : SIETk (Simple Inference Engine - Tk consulting environment)
#
################################################################################
# Version : 1.000
# Dated   : 4 February 2002
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Notes
# -----
# This is a GUI front end to the SIE engine and allows the user to consult a
# knowledgebase with a mouse. There are some small counters to show how the 
# rules and attributes are doing. I hope to expand this in the future.
#
# Version : 1.100
# Dated   : 4 February 2002
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Notes
# -----
# Typical, you update the site and then see a minor bug. The counters for the
# rules and attributes were not being updated in sync with the text window.
# Sorted out a few minor update issues and cleared the text when you do a load.
################################################################################
# Credits
# -------
# Matz and Hidetoshi Nagai for their advice on getting my first Tk interface up
# and running. Cheers.
################################################################################

class SIEtk
	require 'tk'
	require 'sie'

	def initialize
		pg = { 'anchor' => 'n', 'side' => 'left', 'padx' => 5, 'pady' => 5 }

		rules_count = @rules_count = TkVariable.new
		rules_valid = @rules_valid = TkVariable.new

		attributes_count = @attributes_count = TkVariable.new
		attributes_set = @attributes_set = TkVariable.new

		rules_count.value = 0
		rules_valid.value = 0

		attributes_count.value = 0
		attributes_set.value = 0

		prc_load = proc {do_load}
		prc_run = proc{do_run}

		root = TkRoot.new() {
			title 'SIE : Simple Inference Engine'
			geometry('500x500+30+30')
		}

		frm_top = TkFrame.new(root) {
			pack('anchor' => 'w')
		}

		@btn_load = TkButton.new(frm_top) {
			text 'Load'
			width 8
			pack pg
			command prc_load
		}

		@btn_run = TkButton.new(frm_top) {
			text 'Run'
			width 8
			state 'disabled'
			pack pg
			command prc_run
		}

		frm_rule = TkFrame.new(root) { pack('anchor' => 'w') }

		TkLabel.new(frm_rule) {
			text 'Rules'
			width 10
			padx 5
			pack pg
		}

		TkLabel.new(frm_rule) {
			textvariable rules_count
			width 10
			padx 5
			borderwidth 2
			relief 'groove'
			pack pg
		}

		TkLabel.new(frm_rule) {
			text 'still active'
			width 10
			padx 5
			pack pg
		}

		TkLabel.new(frm_rule) {
			textvariable rules_valid
			width 10
			padx 5
			borderwidth 2
			relief 'groove'
			pack pg
		}

		frm_attributes = TkFrame.new(root) { pack('anchor' => 'w') }

		TkLabel.new(frm_attributes) {
			text 'Attributes'
			width 10
			padx 5
			pack pg
		}

		TkLabel.new(frm_attributes) {
			textvariable attributes_count
			width 10
			padx 5
			borderwidth 2
			relief 'groove'
			pack pg
		}

		TkLabel.new(frm_attributes) {
			text 'set'
			width 10
			padx 5
			pack pg
		}

		TkLabel.new(frm_attributes) {
			textvariable attributes_set
			width 10
			padx 5
			borderwidth 2
			relief 'groove'
			pack pg
		}

		@text = TkText.new(root) {
			background 'white'
			width 60
			height 30
			yscrollbar(TkScrollbar.new.pack('side' => 'right', 'fill' => 'y'))
			pack('side' => 'left', 'expand' => 1, 'fill' => 'both')
		}

		Tk.mainloop
	end

	private

	def do_load
		types = [
			['Knowledge Bases', '.xml'], 
			['All files', '*']
		]

		@filename = Tk.getOpenFile('filetypes'=>types)

		if @filename != '' then
			@btn_run.configure('state' => 'active')
			@text.delete(1.0, 'end')
			@rules_count.value = 0
			@rules_valid.value = 0
			@attributes_count.value = 0
			@attributes_set.value = 0
		end
	end

	def do_run
		@text.delete(1.0, 'end')

		@btn_load.configure('state' => 'disabled')
		@btn_run.configure('state' => 'disabled')

		@s = SIE.new(@filename)
		updatecounts

		while @s.run == SIE::MORE do
			log(@s.log)
			@s.user_answer = askaquestion(@s.user_text, @s.user_responses)
		end
		log(@s.log)

		case @s.status
		when SIE::ERROR
			log("-- There was some sort of error! #{@s.user_text}\n")
		when SIE::COMPLETE
			log("-- Success! #{@s.user_text}\n")
		when SIE::FAILED
			log("-- Sorry, I do not know\n")
		end

		@btn_load.configure('state' => 'active')
		@btn_run.configure('state' => 'active')
	end

	def askaquestion(question, responses)
		keys = Hash.new
		keys['title'] = 'Can you tell me...'
		keys['message'] = question
		keys['bitmap'] = 'info'
		keys['buttons'] = responses

		answer = TkDialog.new(keys).value

		return responses[answer]
	end

	def log(text)
		@text.insert('end', text)
		@text.see('end')
		updatecounts
	end

	def updatecounts
		@rules_count.value = @s.rules.length
		valid = 0
		@s.rules.each {|r|
			valid += 1 if r.active
		}
		@rules_valid.value = valid

		@attributes_count.value = @s.knowledge.length
		valid = 0
		@s.knowledge.each_key {|k|
			valid += 1 if @s.knowledge[k] != ''
		}
		@attributes_set.value = valid
	end
end

s = SIEtk.new
