#!ruby

require 'sie'

################################################################################
# Now an example of you to use it
################################################################################

def selectfromlist(list)
	answer = 0

	while answer == 0 do
		counter = 1

		list.each {|r|
			print " #{counter}. #{r}\n"
			counter += 1
		}

		print '** '
		answer = gets
		answer.chomp!
		answer = answer.to_i

		if answer < 1 then
			answer = 0
		elsif answer > list.length then
			answer = 0
		end
	end

	return list[(answer - 1)]
end

puts "Select a database"
puts "================="
s = SIE.new(selectfromlist(['animal.xml', 'glass.xml', 'doctor.xml']))

while s.run == SIE::MORE do
	puts s.user_text
	s.user_answer = selectfromlist(s.user_responses)
end

case s.status
when SIE::ERROR
	puts "-- There was some sort of error! #{s.user_text}"
when SIE::COMPLETE
	puts "-- Success! #{s.user_text}"
when SIE::FAILED
	puts "-- Sorry, I do not know"
end

f = File.new("log.txt", "w")
f.puts s.log
f.close
