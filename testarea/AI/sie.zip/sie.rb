################################################################################
# Class   : SIE (Simple Inference Engine)
#
################################################################################
# Version : 1.000
# Dated   : 29 October 2001
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Notes
# -----
# First Ruby implementation
#
# Version : 1.100
# Dated   : 12 January 2002
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Notes
# -----
# A complete rewrite to allow the use of XML knowledge bases. Requires the REXML
# parser. Interface has changed and well as the core engine itself. This is to 
# allow the extension of the system with new interfaces such as a GUI based
# consultation system, a knowledgebase editing tool or an analysis suite.
#
# We also can now have user responses other than 'yes' or 'no'.
#
# Error checking, would be nice
#
# Version : 1.110
# Dated   : 5 February 2002
# Author  : Peter Hickman (peterhi@shake.demon.co.uk)
#
# Notes
# -----
# Exposed rules and knowledge as readers for the Tk based runner.
################################################################################
# Methods
# -------
# new(filename)
#   Creates an instance of the inference engine loaded with the knowledgebase
#   from <filename>.
#
# run
#   Makes a single pass of the knowledge base and returns a status code:
#      SIE::ERROR
#         The consultation has ended with an error. Use the user_text
#         method to obtain a textual explanation of the error
#      SIE::COMPLETE
#         The consultation has ended with an answer. The user_text
#         method will tell you what the answer is.
#      SIE::FAILED
#         The consultation has ended without producing an answer.
#         Sorry.
#      SIE::MORE 
#         The consultation is still in progress but the user has
#         to answer a question. The question is in the user_text
#         method and a list of appropriate answers is in the
#         user_responses method.
#
# log
#   As SIE runs it writes a log of all the actions taken. This method can be 
#   used to retreive the contents of that log. When called it clears the log
#   and so can be called as SIE is being run.
#
# status
#   The status code is returned by the run method, the value of the last call
#   to run can be retreived with this method.
#
# user_text
#   When SIE stops with a SIE::MORE message the question to ask the user can be
#   retrieved from this method.
#
# user_responses
#   This is a list of valid responses for the user to use when answering the 
#   question given in the user_text method.
#
# user_answer(answer)
#   When the user has answered SIE's question place return their answer to SIE 
#   via this method before calling run.
################################################################################

class Rule
	def initialize(name, conditions, actions)
		@name = name
		@conditions = conditions
		@actions = actions
		@active = true
	end

	def inactive
		@active = false
	end

	attr_reader :conditions, :actions, :name, :active
end

class Question
	def initialize(text, responses)
		@text = text
		@responses = responses
	end

	attr_reader :text, :responses
end

class SIE
	require 'rexml/document'

	ERROR = 0
	MORE = 1
	COMPLETE = 2
	FAILED = 3

	def initialize(filename)
		@rules = ''
		@questions = ''
		@goalvar = ''
		@goaltext = ''
		@knowledge = Hash.new

		@user_attribute = ''
		@user_text = ''
		@user_responses = ''
		@user_answer = ''
		@status = ''
		@logtext = ''

		file = File.open(filename, "r")

		REXML::Document.new(file).elements.each("/knowledgebase/*") {|e|
			case e.name
			when "goal"
				@goalvar = e.text("attribute")
				@goaltext = e.text("text")
			when "rules"
				@rules = readrules(e)
			when "questions"
				@questions = readquestions(e)
			end
		}

		@rules.each {|r|
			r.conditions.each_key {|k|
				@knowledge[k] = ''
			}
			r.actions.each_key {|k|
				@knowledge[k] = ''
			}
		}

		logging("=" * 78)
		logging("Started #{Time.now}")
		logging("Reading knowledge base from #{filename}")
		logging("=" * 78)
		logging("")
		logging("There are #{@rules.length} rules")
		logging("There are #{@questions.length} questions")
		logging("There are #{@knowledge.length} attributes")
		logging("")
	end

	def log
		text = @logtext
		@logtext = ''
		return text
	end

	def run
		didsomething = false

		if @user_attribute != '' then
			makeknown(@user_attribute, @user_answer)

			@user_attribute = ''
			@user_text = ''
			@user_responses = ''
			@user_answer = ''

			didsomething = true
		end

		if goalset? then
			@status = COMPLETE
			return @status
		end

		@rules.each {|r|
			if r.active then
				logging("\nExamining rule #{r.name}")

				ok = true

				r.conditions.each_pair {|k, v|
					if @knowledge[k] == '' then
						if not @questions.has_key?(k) then
							logging("Rule cannot be resolved at present")

							ok = false
							break
						end
					end
				}

				if ok then
					r.conditions.each_pair {|k, v|
						if @knowledge[k] == '' then
							if @questions.has_key?(k) then
								logging("Asking user to set #{k} to #{@questions[k].responses.join(', ')}")
								logging("Question is #{@questions[k].text}")

								@user_attribute = k
								@user_text = @questions[k].text
								@user_responses = @questions[k].responses
								@user_answer = ''

								@status = MORE
								return @status
							end
						end
					}
				end

				if ok then
					logging("Rule passed")
					r.actions.each_pair {|k, v| makeknown(k, v) }
					r.inactive

					didsomething = true

					if goalset? then
						@status = COMPLETE
						return @status
					end
				end
			end
		}

		if goalset? then
			@status = COMPLETE
		elsif didsomething == false then
			@user_text = 'Failed'
			@status = FAILED
		else
			# we did something but have nothing to ask the user, recurse!
			@status = run
		end

		return @status
	end

	attr_reader :user_text, :user_responses, :status, :rules, :knowledge
	attr_writer :user_answer

	private

	def goalset?
		if @knowledge[@goalvar] != '' then
			logging("\nThe goal (#{@goalvar}) has been set")
			logging(theansweris)

			@user_text = theansweris

			return true
		else
			return false
		end
	end

	def makeknown(attribute, value)
		logging("Setting #{attribute} to #{value}")

		@knowledge[attribute] = value

		@rules.each {|r|
			if r.active and r.conditions.has_key?(attribute) and r.conditions[attribute] != value then
				logging("Rule #{r.name} is now inactive")
				r.inactive
			end
		}
	end

	def logging(message)
		@logtext << "#{message}\n"
	end

	def theansweris
		list = @goaltext.split
		x = ''

		list.each {|t|
			if t == @goalvar then
				x << @knowledge[t]
			else 
				x << t
			end
			x << ' '
		}

		return x
	end

	def readrulescora(element, text)
		data = Hash.new

		element.elements.each(text) {|e|
			name = e.text("attribute")
			value = e.text("value")
			data[name] = value
		}

		return data
	end

	def readrules(element)
		rules = Array.new

		element.elements.each("rule") {|r|
			conds = ''
			acts = ''
			name = ''

			r.elements.each("conditions") {|c|
				conds = readrulescora(c, "condition")
			}

			r.elements.each("actions") {|a|
				acts = readrulescora(a, "action")
			}

			name = r.text("name")

			rules << Rule.new(name, conds, acts)
		}

		return rules
	end

	def readquestions(element)
		questions = Hash.new

		element.elements.each("question") {|q|
			name = ''
			value = ''
			responses = Array.new

			name = q.text("attribute")

			value = q.text("text")

			q.elements.each("response") {|r|
				responses << r.text
			}

			questions[name] = Question.new(value, responses)
		}

		return questions
	end
end
