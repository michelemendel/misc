class Comp2
	def say(str)
		puts "#{self.class.name} says #{str}"
	end
end