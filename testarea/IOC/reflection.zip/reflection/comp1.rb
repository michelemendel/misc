class Comp1
	def say(str)
		puts "#{self.class.name} says #{str}"
	end
end